<?php

namespace App\Console\Commands;

use App\Http\Controllers\BatchScrapeController;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class BatchScrapeCommand extends Command
{
    protected $signature   = 'batch:scrape {--from= : Tanggal mulai YYYY-MM-DD} {--to= : Tanggal akhir YYYY-MM-DD}';
    protected $description = 'Batch scraping semua pangkalan via Playwright';

    public function handle(): int
    {
        $from = $this->option('from') ?? now()->startOfWeek()->toDateString();
        $to   = $this->option('to')   ?? now()->toDateString();

        $this->info("[BatchScrape] Mulai: {$from} s/d {$to}");

        $pythonPath   = env('PYTHON_PATH', 'python');
        $scriptPath   = base_path('scripts/auto_login_batch.py');
        $accountPath  = base_path('scripts/accounts.json');

        // Output ke FILE — bukan stdout (hindari buffer overflow)
        $resultFile   = storage_path('app/batch_result.json');

        if (! file_exists($scriptPath)) {
            $this->error("Script tidak ditemukan: {$scriptPath}");
            return 1;
        }

        if (! file_exists($accountPath)) {
            $this->error("accounts.json tidak ditemukan: {$accountPath}");
            return 1;
        }

        // Hapus result lama
        if (file_exists($resultFile)) {
            unlink($resultFile);
        }

        set_time_limit(0);
        Cache::put('batch_scrape_running', true, now()->addHours(2));

        // Jalankan Python dengan --output ke file
        $cmd = sprintf(
            '%s %s --accounts %s --from %s --to %s --output %s 2>&1',
            escapeshellcmd($pythonPath),
            escapeshellarg($scriptPath),
            escapeshellarg($accountPath),
            escapeshellarg($from),
            escapeshellarg($to),
            escapeshellarg($resultFile),
        );

        $this->info("Menjalankan Playwright...");
        $this->info("(Output disimpan ke: {$resultFile})");

        // Jalankan dan tampilkan progress secara realtime
        $handle = popen($cmd, 'r');
        if ($handle) {
            while (! feof($handle)) {
                $line = fgets($handle, 4096);
                if ($line !== false) {
                    $line = trim($line);
                    if ($line) {
                        $this->line($line);

                        // Update progress cache dari baris output
                        // Format: [N/TOTAL] LABEL...
                        if (preg_match('/\[(\d+)\/(\d+)\]\s+(.+?)(\s+\(|$)/', $line, $m)) {
                            Cache::put('batch_scrape_progress', [
                                'current' => (int) $m[1],
                                'total'   => (int) $m[2],
                                'label'   => trim($m[3]),
                            ], now()->addHours(2));
                        }
                    }
                }
            }
            pclose($handle);
        }

        // Cek apakah file hasil ada
        if (! file_exists($resultFile)) {
            $this->error("File hasil tidak ditemukan: {$resultFile}");
            $this->error("Kemungkinan Python gagal dijalankan.");
            Cache::forget('batch_scrape_running');
            return 1;
        }

        $this->info("\nLogin batch selesai. Mengimport data ke database...");

        // Import ke database
        try {
            $controller = app(BatchScrapeController::class);
            $stats      = $controller->importResult($resultFile);

            $this->info("✓ Berhasil : {$stats['berhasil']} pangkalan");
            $this->info("✗ Gagal    : {$stats['gagal']} pangkalan");
            $this->info("+ Transaksi baru: {$stats['total_baru']}");

            Log::info("[BatchScrape] Selesai", $stats);

        } catch (\Exception $e) {
            $this->error("Import gagal: " . $e->getMessage());
            Cache::forget('batch_scrape_running');
            return 1;
        }

        Cache::forget('batch_scrape_running');
        return 0;
    }
}
