<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use App\Models\DailySummary;
use App\Models\NikViolation;
use App\Models\PangkalanSession;
use App\Models\PangkalanToken;
use App\Models\ScrapeLog;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class BatchScrapeController extends Controller
{
    private string $pythonPath;
    private string $scriptsPath;
    private string $accountsPath;

    public function __construct()
    {
        $this->pythonPath   = env('PYTHON_PATH', 'python');
        $this->scriptsPath  = base_path('scripts');
        $this->accountsPath = base_path('scripts/accounts.json');
    }

    /**
     * Halaman batch scrape — tampilkan daftar akun dari accounts.json
     */
    public function index()
    {
        $accounts   = $this->loadAccounts();
        $hasScript  = file_exists($this->scriptsPath . '/auto_login_batch.py');
        $hasAccounts = ! empty($accounts);
        $lastLogs   = ScrapeLog::latest('scraped_at')->limit(10)->get();

        return view('dashboard.batch-scrape', compact(
            'accounts', 'hasScript', 'hasAccounts', 'lastLogs'
        ));
    }

    /**
     * Jalankan batch scraping semua pangkalan di accounts.json
     */
    public function run(Request $request)
    {
        $request->validate([
            'from' => 'required|date',
            'to'   => 'required|date|after_or_equal:from',
        ]);

        if (! file_exists($this->scriptsPath . '/auto_login_batch.py')) {
            return back()->withErrors(['msg' => 'Script auto_login_batch.py tidak ditemukan di folder scripts/']);
        }

        if (! file_exists($this->accountsPath)) {
            return back()->withErrors(['msg' => 'accounts.json tidak ditemukan di folder scripts/']);
        }

        $cmd = sprintf(
            '%s %s --accounts %s --from %s --to %s 2>nul',
            escapeshellcmd($this->pythonPath),
            escapeshellarg($this->scriptsPath . '/auto_login_batch.py'),
            escapeshellarg($this->accountsPath),
            escapeshellarg($request->from),
            escapeshellarg($request->to),
        );

        Log::info("[BatchScrape] Menjalankan: {$request->from} s/d {$request->to}");

        $output   = [];
        $exitCode = 0;
        exec($cmd, $output, $exitCode);

        $outputStr = implode("\n", $output);
        $jsonStart = strrpos($outputStr, '{');

        if ($jsonStart === false) {
            Log::error("[BatchScrape] Output tidak valid: " . $outputStr);
            return back()->withErrors(['msg' => 'Script gagal dijalankan. Cek log Laravel.']);
        }

        $batchResult = json_decode(substr($outputStr, $jsonStart), true);

        if (! $batchResult || ! $batchResult['success']) {
            return back()->withErrors(['msg' => $batchResult['error'] ?? 'Batch scrape gagal']);
        }

        // Proses hasil dari setiap pangkalan
        $stats = ['berhasil' => 0, 'gagal' => 0, 'total_txn' => 0, 'total_baru' => 0];

        foreach ($batchResult['results'] as $result) {
            if (! $result['success'] || empty($result['transactions'])) {
                $stats['gagal']++;
                $this->logScrape(
                    $result['pangkalan_id'] ?? 'unknown',
                    $request->from, $request->to,
                    'failed', 0, 0,
                    $result['error'] ?? 'Login gagal'
                );
                continue;
            }

            $pangkalanId = $result['pangkalan_id'];
            $storeName   = $result['store_name'] ?? $result['label'];

            // Simpan/update token dan info pangkalan
            $this->savePangkalanInfo($result);

            // Simpan transaksi (dengan deduplikasi)
            $saved = $this->saveTransactions(
                $result['transactions'],
                $pangkalanId,
                $storeName
            );

            // Simpan summary harian
            if (! empty($result['summary'])) {
                $this->saveDailySummary($result['summary'], $pangkalanId);
            }

            // Deteksi pelanggaran NIK
            $this->detectViolations($pangkalanId, $request->from, $request->to);

            $this->logScrape(
                $pangkalanId,
                $request->from, $request->to,
                'success',
                count($result['transactions']),
                $saved
            );

            $stats['berhasil']++;
            $stats['total_txn']  += count($result['transactions']);
            $stats['total_baru'] += $saved;
        }

        $msg = "Batch selesai: {$stats['berhasil']} pangkalan berhasil, "
             . "{$stats['gagal']} gagal. "
             . "Total {$stats['total_baru']} transaksi baru disimpan "
             . "dari {$stats['total_txn']} data API.";

        return back()->with('success', $msg);
    }

    /**
     * Upload / update accounts.json
     */
    public function updateAccounts(Request $request)
    {
        $request->validate([
            'accounts_json' => 'required|string',
        ]);

        $accounts = json_decode($request->accounts_json, true);

        if (! is_array($accounts)) {
            return back()->withErrors(['accounts_json' => 'Format JSON tidak valid']);
        }

        // Validasi struktur
        foreach ($accounts as $i => $acc) {
            if (empty($acc['email']) || empty($acc['pin'])) {
                return back()->withErrors([
                    'accounts_json' => "Baris ke-" . ($i+1) . " tidak punya field email atau pin"
                ]);
            }
        }

        // Simpan ke file
        if (! is_dir($this->scriptsPath)) {
            mkdir($this->scriptsPath, 0755, true);
        }

        file_put_contents(
            $this->accountsPath,
            json_encode($accounts, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
        );

        return back()->with('success', count($accounts) . ' akun pangkalan berhasil disimpan.');
    }

    // ── Helpers ──────────────────────────────────────────────────

    private function savePangkalanInfo(array $result): void
    {
        $pangkalanId = $result['pangkalan_id'];

        // Update atau buat session pangkalan
        PangkalanSession::updateOrCreate(
            ['pangkalan_id' => $pangkalanId],
            [
                'label'           => $result['store_name'] ?? $result['label'],
                'username'        => $result['email'],
                'registration_id' => $result['registration_id'],
                'last_login_at'   => now(),
                'is_active'       => true,
            ]
        );

        // Simpan token
        if ($result['token']) {
            try {
                $parts   = explode('.', $result['token']);
                $payload = json_decode(base64_decode(
                    str_pad(strtr($parts[1], '-_', '+/'),
                    strlen($parts[1]) + (4 - strlen($parts[1]) % 4) % 4, '=')
                ), true);

                PangkalanToken::updateOrCreate(
                    ['pangkalan_id' => $pangkalanId],
                    [
                        'label'            => $result['store_name'] ?? $result['label'],
                        'token'            => $result['token'],
                        'token_issued_at'  => isset($payload['iat']) ? Carbon::createFromTimestamp($payload['iat']) : now(),
                        'token_expires_at' => isset($payload['exp']) ? Carbon::createFromTimestamp($payload['exp']) : null,
                        'is_active'        => true,
                    ]
                );
            } catch (\Exception $e) {
                Log::error('[BatchScrape] Gagal simpan token: ' . $e->getMessage());
            }
        }
    }

    private function saveTransactions(array $customers, string $pangkalanId, string $storeName): int
    {
        $saved = 0;

        foreach ($customers as $c) {
            try {
                $txAt = Carbon::parse($c['createdAt'])->setTimezone('Asia/Jakarta');

                $exists = Transaction::where('nationality_id', $c['nationalityId'])
                    ->where('name',           $c['name'])
                    ->where('transaction_at', $txAt)
                    ->exists();

                if ($exists) continue;

                Transaction::create([
                    'customer_report_id' => $c['customerReportId'],
                    'nationality_id'     => $c['nationalityId'],
                    'name'               => $c['name'],
                    'category'           => $c['categories'][0] ?? 'Rumah Tangga',
                    'total'              => $c['total'],
                    'transaction_at'     => $txAt,
                    'transaction_date'   => $txAt->toDateString(),
                    'pangkalan_id'       => $pangkalanId,
                    'store_name'         => $storeName,  // ← nama pangkalan dicap di tiap transaksi
                ]);

                $saved++;
            } catch (\Exception $e) {
                Log::warning('[BatchScrape] Gagal simpan transaksi: ' . $e->getMessage());
            }
        }

        return $saved;
    }

    private function saveDailySummary(array $summary, string $pangkalanId): void
    {
        DailySummary::updateOrCreate(
            ['pangkalan_id' => $pangkalanId, 'summary_date' => $summary['date']],
            [
                'sold'   => $summary['sold']   ?? 0,
                'modal'  => $summary['modal']  ?? 0,
                'profit' => $summary['profit'] ?? 0,
                'gross'  => $summary['gross']  ?? 0,
            ]
        );
    }

    private function detectViolations(string $pangkalanId, string $from, string $to, int $minInterval = 7): void
    {
        $groups = Transaction::where('pangkalan_id', $pangkalanId)
            ->whereBetween('transaction_date', [$from, $to])
            ->orderBy('transaction_date')
            ->get()
            ->groupBy(fn($t) => $t->nationality_id . '||' . $t->name);

        foreach ($groups as $txns) {
            $dates = $txns->pluck('transaction_date')
                ->map(fn($d) => Carbon::parse($d))
                ->sort()->values();

            for ($i = 1; $i < $dates->count(); $i++) {
                $gap      = $dates[$i-1]->diffInDays($dates[$i]);
                $severity = $gap < $minInterval * 0.5 ? 'alert' : 'warn';

                if ($gap < $minInterval) {
                    NikViolation::firstOrCreate(
                        [
                            'nationality_id'        => $txns->first()->nationality_id,
                            'prev_transaction_date' => $dates[$i-1]->toDateString(),
                            'curr_transaction_date' => $dates[$i]->toDateString(),
                        ],
                        [
                            'name'              => $txns->first()->name,
                            'gap_days'          => $gap,
                            'min_interval_days' => $minInterval,
                            'severity'          => $severity,
                        ]
                    );
                }
            }
        }
    }

    private function logScrape(string $pangkalanId, string $from, string $to,
                                string $status, int $fetched, int $saved, ?string $error = null): void
    {
        ScrapeLog::create([
            'pangkalan_id'    => $pangkalanId,
            'start_date'      => $from,
            'end_date'        => $to,
            'status'          => $status,
            'records_fetched' => $fetched,
            'records_saved'   => $saved,
            'error_message'   => $error,
            'scraped_at'      => now(),
        ]);
    }

    private function loadAccounts(): array
    {
        if (! file_exists($this->accountsPath)) return [];
        $content = file_get_contents($this->accountsPath);
        $data    = json_decode($content, true);
        return is_array($data) ? $data : [];
    }
}
