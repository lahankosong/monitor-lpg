<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\TokenCaptureController;
use App\Http\Controllers\TokenInputController;
use App\Http\Controllers\PangkalanManagerController;
use App\Http\Controllers\BatchScrapeController;
use Illuminate\Support\Facades\Route;

Route::prefix('dashboard')->name('dashboard.')->group(function () {

    Route::get('/',           [DashboardController::class, 'index'])->name('index');
    Route::get('/nik',        [DashboardController::class, 'nikList'])->name('nik.list');
    Route::get('/nik/detail', [DashboardController::class, 'nikDetail'])->name('nik.detail');
    Route::get('/export/csv', [DashboardController::class, 'exportCsv'])->name('export.csv');
    Route::post('/scrape',    [DashboardController::class, 'triggerScrape'])->name('scrape');

    // Input token manual
    Route::get('/token/input',     [TokenInputController::class, 'index'])->name('token.input');
    Route::post('/token/input',    [TokenInputController::class, 'store'])->name('token.input.store');
    Route::post('/token/rescrape', [TokenInputController::class, 'rescrape'])->name('token.rescrape');

    // Manager pangkalan
    Route::get('/pangkalan',             [PangkalanManagerController::class, 'index'])->name('pangkalan.list');
    Route::post('/pangkalan',            [PangkalanManagerController::class, 'store'])->name('pangkalan.store');
    Route::post('/pangkalan/scrape-all', [PangkalanManagerController::class, 'scrapeAll'])->name('pangkalan.scrape-all');
    Route::post('/pangkalan/{id}/scrape',[PangkalanManagerController::class, 'scrapeOne'])->name('pangkalan.scrape-one');
    Route::delete('/pangkalan/{id}',     [PangkalanManagerController::class, 'destroy'])->name('pangkalan.destroy');

    // ── Batch scrape via Playwright ──────────────────────────────
    Route::get('/batch',           [BatchScrapeController::class, 'index'])->name('batch.index');
    Route::post('/batch/run',      [BatchScrapeController::class, 'run'])->name('batch.run');
    Route::post('/batch/accounts', [BatchScrapeController::class, 'updateAccounts'])->name('batch.accounts');

    // Token lama
    Route::post('/token', [DashboardController::class, 'saveToken'])->name('token.save');
});

Route::match(['OPTIONS','POST'], '/dashboard/token/capture', [TokenCaptureController::class, 'capture'])
    ->name('token.capture')
    ->withoutMiddleware([\Illuminate\Foundation\Http\Middleware\VerifyCsrfToken::class]);

Route::get('/', fn() => redirect()->route('dashboard.index'));
