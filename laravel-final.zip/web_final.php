<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\TokenCaptureController;
use App\Http\Controllers\TokenInputController;
use Illuminate\Support\Facades\Route;

// ── Dashboard ────────────────────────────────────────────────────
Route::prefix('dashboard')->name('dashboard.')->group(function () {

    Route::get('/',           [DashboardController::class, 'index'])->name('index');
    Route::get('/nik',        [DashboardController::class, 'nikList'])->name('nik.list');
    Route::get('/nik/detail', [DashboardController::class, 'nikDetail'])->name('nik.detail');
    Route::get('/export/csv', [DashboardController::class, 'exportCsv'])->name('export.csv');
    Route::post('/scrape',    [DashboardController::class, 'triggerScrape'])->name('scrape');
    Route::post('/token',     [DashboardController::class, 'saveToken'])->name('token.save');

    // ── Halaman input token (pengganti extension) ────────────────
    Route::get('/token/input',    [TokenInputController::class, 'index'])->name('token.input');
    Route::post('/token/input',   [TokenInputController::class, 'store'])->name('token.input.store');
    Route::post('/token/rescrape',[TokenInputController::class, 'rescrape'])->name('token.rescrape');

    // ── Pangkalan ────────────────────────────────────────────────
    Route::get('/pangkalan',             [TokenCaptureController::class, 'pangkalanList'])->name('pangkalan.list');
    Route::post('/pangkalan/scrape-all', [TokenCaptureController::class, 'scrapeAll'])->name('pangkalan.scrape-all');
    Route::post('/pangkalan/{id}/label', [TokenCaptureController::class, 'updateLabel'])->name('pangkalan.label');
});

// ── Extension endpoint (opsional, tetap ada) ─────────────────────
Route::match(['OPTIONS','POST'], '/dashboard/token/capture', [TokenCaptureController::class, 'capture'])
    ->name('token.capture')
    ->withoutMiddleware([\Illuminate\Foundation\Http\Middleware\VerifyCsrfToken::class]);

Route::get('/', fn() => redirect()->route('dashboard.index'));
