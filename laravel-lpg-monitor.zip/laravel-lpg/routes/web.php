<?php

use App\Http\Controllers\DashboardController;
use Illuminate\Support\Facades\Route;

Route::prefix('dashboard')->name('dashboard.')->group(function () {

    // Halaman utama — ringkasan + grafik
    Route::get('/',         [DashboardController::class, 'index'])->name('index');

    // Monitoring NIK
    Route::get('/nik',           [DashboardController::class, 'nikList'])->name('nik.list');
    Route::get('/nik/{nik}',     [DashboardController::class, 'nikDetail'])->name('nik.detail');

    // Aksi
    Route::post('/scrape',       [DashboardController::class, 'triggerScrape'])->name('scrape');
    Route::post('/token',        [DashboardController::class, 'saveToken'])->name('token.save');
    Route::get('/export/csv',    [DashboardController::class, 'exportCsv'])->name('export.csv');
});

// Redirect root ke dashboard
Route::get('/', fn() => redirect()->route('dashboard.index'));
