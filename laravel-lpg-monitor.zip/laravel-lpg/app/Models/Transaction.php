<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Carbon\Carbon;

class Transaction extends Model
{
    protected $fillable = [
        'customer_report_id', 'nationality_id', 'name',
        'category', 'total', 'transaction_at',
        'transaction_date', 'pangkalan_id',
    ];

    protected $casts = [
        'transaction_at'   => 'datetime',
        'transaction_date' => 'date',
        'total'            => 'integer',
    ];

    // ── Relationships ──────────────────────────────────────────────

    public function violations()
    {
        return $this->hasMany(NikViolation::class, 'nationality_id', 'nationality_id');
    }

    // ── Scopes ─────────────────────────────────────────────────────

    public function scopeByNik(Builder $q, string $nik): Builder
    {
        return $q->where('nationality_id', $nik);
    }

    public function scopeDateRange(Builder $q, string $from, string $to): Builder
    {
        return $q->whereBetween('transaction_date', [$from, $to]);
    }

    public function scopeRumahtangga(Builder $q): Builder
    {
        return $q->where('category', 'Rumah Tangga');
    }

    // ── Helpers ────────────────────────────────────────────────────

    /**
     * Ambil semua transaksi per NIK dalam rentang tanggal,
     * diurutkan ascending untuk analisis interval.
     */
    public static function groupByNik(string $from, string $to): \Illuminate\Support\Collection
    {
        return static::dateRange($from, $to)
            ->orderBy('transaction_date')
            ->get()
            ->groupBy('nationality_id');
    }

    /**
     * Hitung ringkasan status NIK berdasarkan interval minimum.
     * Return: ['aman'=>N, 'warn'=>N, 'alert'=>N, 'new'=>N]
     */
    public static function nikStatusSummary(string $from, string $to, int $minInterval = 7): array
    {
        $groups = static::groupByNik($from, $to);
        $counts = ['aman' => 0, 'warn' => 0, 'alert' => 0, 'new' => 0];

        foreach ($groups as $nik => $txns) {
            $status = static::analyzeNikStatus($txns, $minInterval);
            $counts[$status]++;
        }

        return $counts;
    }

    /**
     * Analisis status satu NIK berdasarkan koleksi transaksinya.
     */
    public static function analyzeNikStatus(\Illuminate\Support\Collection $txns, int $minInterval = 7): string
    {
        if ($txns->count() === 1) return 'new';

        $dates   = $txns->pluck('transaction_date')->map(fn($d) => Carbon::parse($d))->sort()->values();
        $gaps    = [];
        $violations = 0;

        for ($i = 1; $i < $dates->count(); $i++) {
            $gap = $dates[$i - 1]->diffInDays($dates[$i]);
            $gaps[] = $gap;
            if ($gap < $minInterval) $violations++;
        }

        $avgGap = count($gaps) ? array_sum($gaps) / count($gaps) : null;

        if ($violations >= 3 || ($avgGap !== null && $avgGap < $minInterval * 0.5)) return 'alert';
        if ($violations >= 1 || ($avgGap !== null && $avgGap < $minInterval * 0.75)) return 'warn';
        return 'aman';
    }
}
