<?php

namespace App\Http\Controllers;

use App\Jobs\ScrapeTransactionsJob;
use App\Models\Transaction;
use App\Models\NikViolation;
use App\Models\DailySummary;
use App\Models\PangkalanToken;
use App\Models\ScrapeLog;
use Carbon\Carbon;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    // ── Halaman utama dashboard ────────────────────────────────────

    public function index(Request $request)
    {
        $from = $request->get('from', now()->startOfMonth()->toDateString());
        $to   = $request->get('to',   now()->toDateString());
        $minInterval = (int) $request->get('interval', 7);

        // Ringkasan status NIK
        $nikStatus  = Transaction::nikStatusSummary($from, $to, $minInterval);
        $totalNik   = array_sum($nikStatus);

        // Ringkasan penjualan
        $summary = DailySummary::whereBetween('summary_date', [$from, $to])->get();
        $totalSold   = $summary->sum('sold');
        $totalGross  = $summary->sum('gross');
        $totalProfit = $summary->sum('profit');

        // Pelanggaran belum diselesaikan
        $openViolations = NikViolation::unresolved()->orderBy('severity', 'desc')->limit(10)->get();

        // Data grafik harian (7 hari terakhir)
        $chartDays  = collect();
        for ($i = 6; $i >= 0; $i--) {
            $date = now()->subDays($i)->toDateString();
            $chartDays->push([
                'date'  => $date,
                'label' => Carbon::parse($date)->format('d/m'),
                'sold'  => DailySummary::where('summary_date', $date)->sum('sold'),
                'txn'   => Transaction::where('transaction_date', $date)->count(),
            ]);
        }

        // Log scraping terbaru
        $lastScrape = ScrapeLog::latest('scraped_at')->first();

        return view('dashboard.index', compact(
            'nikStatus', 'totalNik', 'from', 'to', 'minInterval',
            'totalSold', 'totalGross', 'totalProfit',
            'openViolations', 'chartDays', 'lastScrape'
        ));
    }

    // ── Halaman daftar NIK ────────────────────────────────────────

    public function nikList(Request $request)
    {
        $from        = $request->get('from', now()->startOfMonth()->toDateString());
        $to          = $request->get('to',   now()->toDateString());
        $minInterval = (int) $request->get('interval', 7);
        $search      = $request->get('search', '');
        $filterStatus = $request->get('status', '');

        $groups = Transaction::dateRange($from, $to)
            ->when($search, fn($q) => $q->where(function($q) use ($search) {
                $q->where('nationality_id', 'like', "%{$search}%")
                  ->orWhere('name', 'like', "%{$search}%");
            }))
            ->orderBy('transaction_date')
            ->get()
            ->groupBy('nationality_id');

        // Analisis tiap NIK
        $nikData = $groups->map(function ($txns) use ($minInterval) {
            $dates  = $txns->pluck('transaction_date')
                ->map(fn($d) => Carbon::parse($d))
                ->sort()->values();

            $gaps       = [];
            $violations = [];
            for ($i = 1; $i < $dates->count(); $i++) {
                $gap = $dates[$i - 1]->diffInDays($dates[$i]);
                $gaps[] = $gap;
                if ($gap < $minInterval) {
                    $violations[] = [
                        'dari'  => $dates[$i - 1]->format('Y-m-d'),
                        'ke'    => $dates[$i]->format('Y-m-d'),
                        'gap'   => $gap,
                        'kurang' => $minInterval - $gap,
                    ];
                }
            }

            $avgGap = count($gaps) ? round(array_sum($gaps) / count($gaps), 1) : null;
            $status = Transaction::analyzeNikStatus($txns, $minInterval);

            return [
                'nik'          => $txns->first()->nationality_id,
                'nama'         => $txns->first()->name,
                'total_txn'    => $txns->count(),
                'total_tabung' => $txns->sum('total'),
                'tgl_pertama'  => $dates->first()?->format('Y-m-d'),
                'tgl_terakhir' => $dates->last()?->format('Y-m-d'),
                'avg_gap'      => $avgGap,
                'violations'   => $violations,
                'status'       => $status,
            ];
        })->values();

        // Filter status
        if ($filterStatus) {
            $nikData = $nikData->filter(fn($n) => $n['status'] === $filterStatus)->values();
        }

        // Urutkan: alert → warn → new → aman
        $order = ['alert' => 0, 'warn' => 1, 'new' => 2, 'aman' => 3];
        $nikData = $nikData->sortBy(fn($n) => $order[$n['status']] ?? 9)->values();

        return view('dashboard.nik', compact(
            'nikData', 'from', 'to', 'minInterval', 'search', 'filterStatus'
        ));
    }

    // ── Detail satu NIK ───────────────────────────────────────────

    public function nikDetail(string $nik, Request $request)
    {
        $from = $request->get('from', now()->subMonths(3)->toDateString());
        $to   = $request->get('to',   now()->toDateString());

        $txns = Transaction::byNik($nik)->dateRange($from, $to)
            ->orderBy('transaction_date')
            ->get();

        abort_if($txns->isEmpty(), 404, 'NIK tidak ditemukan');

        $minInterval = (int) $request->get('interval', 7);
        $status      = Transaction::analyzeNikStatus($txns, $minInterval);
        $violations  = NikViolation::where('nationality_id', $nik)->orderBy('curr_transaction_date', 'desc')->get();

        return view('dashboard.nik-detail', compact('txns', 'nik', 'status', 'violations', 'from', 'to'));
    }

    // ── Trigger scraping manual ───────────────────────────────────

    public function triggerScrape(Request $request)
    {
        $request->validate([
            'from'        => 'required|date',
            'to'          => 'required|date|after_or_equal:from',
            'pangkalan_id' => 'nullable|string|max:50',
        ]);

        ScrapeTransactionsJob::dispatch(
            $request->from,
            $request->to,
            $request->pangkalan_id
        );

        return back()->with('success', "Scraping dijadwalkan: {$request->from} s/d {$request->to}");
    }

    // ── Simpan / update Bearer token ─────────────────────────────

    public function saveToken(Request $request)
    {
        $request->validate([
            'pangkalan_id' => 'required|string|max:50',
            'label'        => 'nullable|string|max:100',
            'token'        => 'required|string',
        ]);

        $token    = trim(str_replace('Bearer ', '', $request->token));
        $expireAt = null;

        // Decode JWT untuk ambil expire time
        try {
            $parts   = explode('.', $token);
            $payload = json_decode(base64_decode(str_pad($parts[1], strlen($parts[1]) + (4 - strlen($parts[1]) % 4) % 4, '=')), true);
            $expireAt = isset($payload['exp']) ? Carbon::createFromTimestamp($payload['exp']) : null;
            $issuedAt = isset($payload['iat']) ? Carbon::createFromTimestamp($payload['iat']) : null;
            $pangkalanIdFromJwt = $payload['sub'] ?? null;
        } catch (\Exception $e) {
            $issuedAt = null;
            $pangkalanIdFromJwt = null;
        }

        PangkalanToken::updateOrCreate(
            ['pangkalan_id' => $request->pangkalan_id],
            [
                'label'            => $request->label,
                'token'            => $token,
                'token_issued_at'  => $issuedAt ?? now(),
                'token_expires_at' => $expireAt,
                'is_active'        => true,
            ]
        );

        $msg = $expireAt
            ? "Token disimpan. Berlaku hingga: {$expireAt->format('d/m/Y H:i')}"
            : 'Token disimpan.';

        return back()->with('success', $msg);
    }

    // ── Ekspor CSV ────────────────────────────────────────────────

    public function exportCsv(Request $request)
    {
        $from = $request->get('from', now()->startOfMonth()->toDateString());
        $to   = $request->get('to',   now()->toDateString());

        $txns = Transaction::dateRange($from, $to)->orderBy('transaction_date')->get();

        $headers = [
            'Content-Type'        => 'text/csv; charset=UTF-8',
            'Content-Disposition' => "attachment; filename=transaksi_{$from}_{$to}.csv",
        ];

        $callback = function () use ($txns) {
            $out = fopen('php://output', 'w');
            fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM UTF-8 agar Excel bisa baca
            fputcsv($out, ['NIK', 'Nama', 'Kategori', 'Jumlah Tabung', 'Tanggal', 'Waktu', 'ID Transaksi']);
            foreach ($txns as $t) {
                fputcsv($out, [
                    $t->nationality_id,
                    $t->name,
                    $t->category,
                    $t->total,
                    $t->transaction_date->format('Y-m-d'),
                    Carbon::parse($t->transaction_at)->format('H:i:s'),
                    $t->customer_report_id,
                ]);
            }
            fclose($out);
        };

        return response()->stream($callback, 200, $headers);
    }
}
