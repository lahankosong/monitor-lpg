@extends('layouts.app')
@section('title', 'Dashboard')

@section('content')

{{-- Header & filter tanggal --}}
<div class="flex items-center justify-between mb-5 flex-wrap gap-3">
  <div>
    <h1 class="text-lg font-semibold">Dashboard Pengawasan LPG Subsidi</h1>
    <p class="text-xs text-gray-500 mt-0.5">
      Monitoring transaksi per NIK Rumah Tangga
      @if($lastScrape)
        · Scraping terakhir: {{ \Carbon\Carbon::parse($lastScrape->scraped_at)->format('d/m H:i') }}
        <span class="{{ $lastScrape->status === 'success' ? 'text-green-600' : 'text-red-600' }}">
          ({{ $lastScrape->status }})
        </span>
      @else
        · Belum ada data scraping
      @endif
    </p>
  </div>
  <form method="GET" class="flex items-center gap-2 flex-wrap">
    <input type="date" name="from" value="{{ $from }}"
           class="border border-gray-300 rounded px-2 py-1.5 text-sm">
    <span class="text-gray-400 text-xs">s/d</span>
    <input type="date" name="to" value="{{ $to }}"
           class="border border-gray-300 rounded px-2 py-1.5 text-sm">
    <select name="interval" class="border border-gray-300 rounded px-2 py-1.5 text-sm">
      <option value="5"  {{ $minInterval==5  ? 'selected' : '' }}>Min 5 hari</option>
      <option value="7"  {{ $minInterval==7  ? 'selected' : '' }}>Min 7 hari</option>
      <option value="14" {{ $minInterval==14 ? 'selected' : '' }}>Min 14 hari</option>
    </select>
    <button type="submit" class="bg-gray-800 text-white rounded px-3 py-1.5 text-sm">Terapkan</button>
    <a href="{{ route('dashboard.export.csv', ['from'=>$from,'to'=>$to]) }}"
       class="border border-gray-300 rounded px-3 py-1.5 text-sm hover:bg-gray-50">
      Ekspor CSV
    </a>
  </form>
</div>

{{-- Kartu metrik --}}
<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
  <div class="bg-white rounded-xl border border-gray-200 p-4">
    <p class="text-xs text-gray-500">Total NIK</p>
    <p class="text-2xl font-semibold mt-1">{{ number_format($totalNik) }}</p>
    <p class="text-xs text-gray-400 mt-0.5">periode ini</p>
  </div>
  <div class="bg-white rounded-xl border border-red-200 p-4">
    <p class="text-xs text-red-500">Frekuensi Tinggi</p>
    <p class="text-2xl font-semibold mt-1 text-red-600">{{ $nikStatus['alert'] }}</p>
    <p class="text-xs text-gray-400 mt-0.5">perlu investigasi</p>
  </div>
  <div class="bg-white rounded-xl border border-amber-200 p-4">
    <p class="text-xs text-amber-500">Perlu Pantau</p>
    <p class="text-2xl font-semibold mt-1 text-amber-600">{{ $nikStatus['warn'] }}</p>
    <p class="text-xs text-gray-400 mt-0.5">interval dekat</p>
  </div>
  <div class="bg-white rounded-xl border border-green-200 p-4">
    <p class="text-xs text-green-500">Total Tabung Terjual</p>
    <p class="text-2xl font-semibold mt-1 text-green-700">{{ number_format($totalSold) }}</p>
    <p class="text-xs text-gray-400 mt-0.5">Omzet: Rp {{ number_format($totalGross) }}</p>
  </div>
</div>

{{-- Grafik + Pelanggaran --}}
<div class="grid md:grid-cols-2 gap-5 mb-6">

  {{-- Grafik penjualan harian --}}
  <div class="bg-white rounded-xl border border-gray-200 p-4">
    <h2 class="font-medium text-sm mb-3">Penjualan 7 Hari Terakhir</h2>
    <div style="position:relative;height:200px">
      <canvas id="chartSales" role="img" aria-label="Grafik penjualan tabung 7 hari terakhir"></canvas>
    </div>
  </div>

  {{-- Daftar pelanggaran terbaru --}}
  <div class="bg-white rounded-xl border border-gray-200 p-4">
    <div class="flex items-center justify-between mb-3">
      <h2 class="font-medium text-sm">Pelanggaran Interval Terbaru</h2>
      <a href="{{ route('dashboard.nik.list', ['status'=>'alert','from'=>$from,'to'=>$to]) }}"
         class="text-xs text-blue-600 hover:underline">Lihat semua →</a>
    </div>
    @forelse($openViolations as $v)
    <div class="flex items-start gap-3 py-2 border-b border-gray-100 last:border-0">
      <span class="{{ $v->severity === 'alert' ? 'badge-alert' : 'badge-warn' }}">
        {{ $v->severity === 'alert' ? 'Alert' : 'Warn' }}
      </span>
      <div class="flex-1 min-w-0">
        <p class="font-medium truncate">{{ $v->name }}</p>
        <p class="text-gray-500 font-mono text-xs">{{ $v->nationality_id }}</p>
        <p class="text-xs text-gray-400">
          {{ \Carbon\Carbon::parse($v->prev_transaction_date)->format('d/m') }}
          → {{ \Carbon\Carbon::parse($v->curr_transaction_date)->format('d/m') }}
          (jarak {{ $v->gap_days }} hari)
        </p>
      </div>
      <a href="{{ route('dashboard.nik.detail', $v->nationality_id) }}"
         class="text-xs text-gray-400 hover:text-gray-700 shrink-0">Detail</a>
    </div>
    @empty
    <p class="text-xs text-gray-400 py-4 text-center">Tidak ada pelanggaran ditemukan</p>
    @endforelse
  </div>

</div>

{{-- Status NIK summary bar --}}
<div class="bg-white rounded-xl border border-gray-200 p-4">
  <div class="flex items-center justify-between mb-2">
    <h2 class="font-medium text-sm">Distribusi Status NIK</h2>
    <a href="{{ route('dashboard.nik.list', ['from'=>$from,'to'=>$to]) }}"
       class="text-xs text-blue-600 hover:underline">Lihat detail →</a>
  </div>
  @if($totalNik > 0)
  <div class="flex rounded-full overflow-hidden h-4 mb-2">
    @if($nikStatus['alert'] > 0)
    <div class="bg-red-500" style="width:{{ $nikStatus['alert']/$totalNik*100 }}%" title="Alert"></div>
    @endif
    @if($nikStatus['warn'] > 0)
    <div class="bg-amber-400" style="width:{{ $nikStatus['warn']/$totalNik*100 }}%" title="Warn"></div>
    @endif
    @if($nikStatus['new'] > 0)
    <div class="bg-blue-400" style="width:{{ $nikStatus['new']/$totalNik*100 }}%" title="Baru"></div>
    @endif
    @if($nikStatus['aman'] > 0)
    <div class="bg-green-400" style="width:{{ $nikStatus['aman']/$totalNik*100 }}%" title="Aman"></div>
    @endif
  </div>
  <div class="flex gap-4 text-xs text-gray-500">
    <span><span class="inline-block w-2.5 h-2.5 rounded-sm bg-red-500 mr-1"></span>Alert: {{ $nikStatus['alert'] }}</span>
    <span><span class="inline-block w-2.5 h-2.5 rounded-sm bg-amber-400 mr-1"></span>Warn: {{ $nikStatus['warn'] }}</span>
    <span><span class="inline-block w-2.5 h-2.5 rounded-sm bg-blue-400 mr-1"></span>Baru: {{ $nikStatus['new'] }}</span>
    <span><span class="inline-block w-2.5 h-2.5 rounded-sm bg-green-400 mr-1"></span>Aman: {{ $nikStatus['aman'] }}</span>
  </div>
  @else
  <p class="text-xs text-gray-400 py-2">Belum ada data transaksi. Klik "Scrape Data" untuk mulai.</p>
  @endif
</div>

@endsection

@push('scripts')
<script>
const days   = @json($chartDays);
const labels = days.map(d => d.label);
const sold   = days.map(d => d.sold);
const txn    = days.map(d => d.txn);

new Chart(document.getElementById('chartSales'), {
  type: 'bar',
  data: {
    labels,
    datasets: [
      { label: 'Tabung terjual', data: sold, backgroundColor: '#3B82F6', yAxisID: 'y' },
      { label: 'Jumlah transaksi', data: txn, type: 'line',
        borderColor: '#F59E0B', backgroundColor: 'transparent',
        pointRadius: 4, tension: 0.3, yAxisID: 'y1' },
    ]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      y:  { beginAtZero: true, ticks: { stepSize: 1 } },
      y1: { beginAtZero: true, position: 'right', grid: { drawOnChartArea: false } },
      x:  { ticks: { autoSkip: false } }
    }
  }
});
</script>
@endpush
