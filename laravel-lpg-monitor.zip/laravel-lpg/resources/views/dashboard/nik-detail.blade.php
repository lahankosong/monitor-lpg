@extends('layouts.app')
@section('title', 'Detail NIK')

@section('content')

@php
  $minInterval = request('interval', 7);
  $nama        = $txns->first()->name;
  $statusLabel = ['alert'=>'Frekuensi Tinggi','warn'=>'Perlu Pantau','aman'=>'Aman','new'=>'Data Baru'];
  $statusClass = ['alert'=>'badge-alert','warn'=>'badge-warn','aman'=>'badge-aman','new'=>'badge-new'];

  $dates    = $txns->pluck('transaction_date')->map(fn($d)=>\Carbon\Carbon::parse($d))->sort()->values();
  $gaps     = [];
  $violations_inline = [];
  for($i=1;$i<$dates->count();$i++){
    $g = $dates[$i-1]->diffInDays($dates[$i]);
    $gaps[] = $g;
    if($g < $minInterval) $violations_inline[] = ['dari'=>$dates[$i-1]->format('d/m'),'ke'=>$dates[$i]->format('d/m'),'gap'=>$g];
  }
  $avgGap    = count($gaps) ? round(array_sum($gaps)/count($gaps),1) : null;
  $totalTabung = $txns->sum('total');
@endphp

<div class="mb-4">
  <a href="{{ route('dashboard.nik.list', ['from'=>$from,'to'=>$to]) }}"
     class="text-xs text-gray-400 hover:text-gray-700">← Kembali ke daftar NIK</a>
</div>

{{-- Header NIK --}}
<div class="bg-white rounded-xl border border-gray-200 p-5 mb-5 flex items-start justify-between flex-wrap gap-4">
  <div>
    <p class="text-xs text-gray-400 mb-1 font-mono">{{ $nik }}</p>
    <h1 class="text-lg font-semibold">{{ $nama }}</h1>
    <p class="text-xs text-gray-500 mt-1">{{ $txns->first()->category }}</p>
  </div>
  <div class="flex flex-wrap gap-3">
    <div class="text-center">
      <p class="text-2xl font-semibold">{{ $txns->count() }}</p>
      <p class="text-xs text-gray-400">Transaksi</p>
    </div>
    <div class="text-center">
      <p class="text-2xl font-semibold">{{ $totalTabung }}</p>
      <p class="text-xs text-gray-400">Total Tabung</p>
    </div>
    <div class="text-center">
      <p class="text-2xl font-semibold {{ $avgGap !== null && $avgGap < $minInterval ? 'text-red-600' : '' }}">
        {{ $avgGap ?? '—' }}
      </p>
      <p class="text-xs text-gray-400">Jarak rata² (hari)</p>
    </div>
    <div class="text-center">
      <p class="text-2xl font-semibold text-red-600">{{ count($violations_inline) }}</p>
      <p class="text-xs text-gray-400">Pelanggaran</p>
    </div>
    <div class="flex items-center">
      <span class="{{ $statusClass[$status] ?? 'badge-new' }}">
        {{ $statusLabel[$status] ?? $status }}
      </span>
    </div>
  </div>
</div>

<div class="grid md:grid-cols-2 gap-5 mb-5">

  {{-- Grafik riwayat pembelian --}}
  <div class="bg-white rounded-xl border border-gray-200 p-4">
    <h2 class="font-medium text-sm mb-3">Riwayat Pembelian</h2>
    <div style="position:relative;height:180px">
      <canvas id="chartNik" role="img" aria-label="Grafik riwayat pembelian NIK ini"></canvas>
    </div>
  </div>

  {{-- Pelanggaran interval --}}
  <div class="bg-white rounded-xl border border-gray-200 p-4">
    <h2 class="font-medium text-sm mb-3">Detail Pelanggaran Interval</h2>
    @if(count($violations_inline) > 0)
      @foreach($violations_inline as $v)
      <div class="flex items-center gap-3 py-1.5 border-b border-gray-100 last:border-0 text-sm">
        <span class="badge-alert text-xs">!</span>
        <span class="text-gray-600">{{ $v['dari'] }} → {{ $v['ke'] }}</span>
        <span class="font-medium text-red-600 ml-auto">{{ $v['gap'] }} hari</span>
        <span class="text-xs text-gray-400">(kurang {{ $minInterval - $v['gap'] }} hari)</span>
      </div>
      @endforeach
    @else
      <p class="text-xs text-gray-400 py-4 text-center">Tidak ada pelanggaran interval pada periode ini</p>
    @endif
  </div>

</div>

{{-- Tabel riwayat transaksi --}}
<div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
  <div class="px-4 py-3 border-b border-gray-100">
    <h2 class="font-medium text-sm">Riwayat Transaksi Lengkap</h2>
  </div>
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500 uppercase tracking-wide">
      <tr>
        <th class="text-left px-4 py-2">#</th>
        <th class="text-left px-4 py-2">Tanggal</th>
        <th class="text-left px-4 py-2">Waktu</th>
        <th class="text-right px-4 py-2">Tabung</th>
        <th class="text-right px-4 py-2">Jarak dari sebelumnya</th>
        <th class="text-left px-4 py-2">Keterangan</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-gray-100">
      @foreach($txns->sortBy('transaction_at') as $idx => $t)
      @php
        $txDate  = \Carbon\Carbon::parse($t->transaction_at);
        $prevDate = $idx > 0 ? \Carbon\Carbon::parse($txns->sortBy('transaction_at')->values()[$idx-1]->transaction_at) : null;
        $gap      = $prevDate ? $prevDate->diffInDays($txDate) : null;
        $isViolation = $gap !== null && $gap < $minInterval;
      @endphp
      <tr class="{{ $isViolation ? 'bg-red-50' : 'hover:bg-gray-50' }}">
        <td class="px-4 py-2.5 text-gray-400">{{ $idx + 1 }}</td>
        <td class="px-4 py-2.5 font-medium">{{ $txDate->format('d/m/Y') }}</td>
        <td class="px-4 py-2.5 text-gray-500">{{ $txDate->format('H:i') }}</td>
        <td class="px-4 py-2.5 text-right font-semibold">{{ $t->total }}</td>
        <td class="px-4 py-2.5 text-right {{ $isViolation ? 'text-red-600 font-semibold' : 'text-gray-500' }}">
          {{ $gap !== null ? $gap.' hari' : '—' }}
        </td>
        <td class="px-4 py-2.5">
          @if($isViolation)
            <span class="badge-alert">Jarak terlalu dekat (min {{ $minInterval }}h)</span>
          @else
            <span class="text-gray-300">—</span>
          @endif
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>

@endsection

@push('scripts')
<script>
const txns = @json($txns->sortBy('transaction_at')->map(fn($t) => [
  'label' => \Carbon\Carbon::parse($t->transaction_at)->format('d/m'),
  'total' => $t->total,
])->values());

new Chart(document.getElementById('chartNik'), {
  type: 'bar',
  data: {
    labels: txns.map(t => t.label),
    datasets: [{
      label: 'Tabung',
      data:  txns.map(t => t.total),
      backgroundColor: txns.map(() => '#3B82F6'),
    }]
  },
  options: {
    responsive: true, maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      y: { beginAtZero: true, ticks: { stepSize: 1 } },
      x: { ticks: { autoSkip: false, maxRotation: 45 } }
    }
  }
});
</script>
@endpush
