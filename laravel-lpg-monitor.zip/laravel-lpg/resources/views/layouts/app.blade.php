<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>Monitor LPG Subsidi – @yield('title', 'Dashboard')</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>
  .badge-alert  { @apply bg-red-100 text-red-800 text-xs px-2 py-0.5 rounded-full font-medium; }
  .badge-warn   { @apply bg-amber-100 text-amber-800 text-xs px-2 py-0.5 rounded-full font-medium; }
  .badge-aman   { @apply bg-green-100 text-green-800 text-xs px-2 py-0.5 rounded-full font-medium; }
  .badge-new    { @apply bg-blue-100 text-blue-800 text-xs px-2 py-0.5 rounded-full font-medium; }
</style>
</head>
<body class="bg-gray-50 text-gray-900 text-sm">

{{-- Navbar --}}
<nav class="bg-white border-b border-gray-200 px-6 py-3 flex items-center gap-6">
  <span class="font-semibold text-base text-gray-800">⛽ Monitor LPG Subsidi</span>
  <a href="{{ route('dashboard.index') }}"
     class="text-gray-600 hover:text-gray-900 {{ request()->routeIs('dashboard.index') ? 'font-medium text-gray-900' : '' }}">
    Dashboard
  </a>
  <a href="{{ route('dashboard.nik.list') }}"
     class="text-gray-600 hover:text-gray-900 {{ request()->routeIs('dashboard.nik.*') ? 'font-medium text-gray-900' : '' }}">
    Monitor NIK
  </a>
  <div class="ml-auto flex items-center gap-3">
    {{-- Form token --}}
    <button onclick="document.getElementById('modal-token').classList.remove('hidden')"
            class="text-xs border border-gray-300 rounded px-3 py-1.5 hover:bg-gray-50">
      + Update Token
    </button>
    {{-- Form scrape --}}
    <button onclick="document.getElementById('modal-scrape').classList.remove('hidden')"
            class="text-xs bg-blue-600 text-white rounded px-3 py-1.5 hover:bg-blue-700">
      Scrape Data
    </button>
  </div>
</nav>

{{-- Flash messages --}}
@if(session('success'))
<div class="bg-green-50 border-b border-green-200 text-green-800 text-xs px-6 py-2">
  ✓ {{ session('success') }}
</div>
@endif
@if(session('error'))
<div class="bg-red-50 border-b border-red-200 text-red-800 text-xs px-6 py-2">
  ✗ {{ session('error') }}
</div>
@endif

{{-- Main content --}}
<main class="p-6">
  @yield('content')
</main>

{{-- Modal: Update Token --}}
<div id="modal-token" class="hidden fixed inset-0 bg-black/40 flex items-center justify-center z-50">
  <div class="bg-white rounded-xl shadow-lg p-6 w-full max-w-md">
    <h2 class="font-semibold text-base mb-4">Update Bearer Token</h2>
    <form action="{{ route('dashboard.token.save') }}" method="POST">
      @csrf
      <div class="space-y-3">
        <div>
          <label class="block text-xs text-gray-500 mb-1">ID Pangkalan</label>
          <input name="pangkalan_id" class="w-full border border-gray-300 rounded px-3 py-2 text-sm"
                 placeholder="mis: PKL-001" required>
        </div>
        <div>
          <label class="block text-xs text-gray-500 mb-1">Nama Pangkalan (opsional)</label>
          <input name="label" class="w-full border border-gray-300 rounded px-3 py-2 text-sm"
                 placeholder="mis: Pangkalan Pak Budi">
        </div>
        <div>
          <label class="block text-xs text-gray-500 mb-1">Bearer Token</label>
          <textarea name="token" rows="4"
                    class="w-full border border-gray-300 rounded px-3 py-2 text-xs font-mono"
                    placeholder="Paste token dari DevTools F12 → Network → Authorization..." required></textarea>
          <p class="text-xs text-gray-400 mt-1">Copy dari DevTools: F12 → Network → request ke api-map.my-pertamina.id → Headers → nilai Authorization (tanpa kata "Bearer ")</p>
        </div>
      </div>
      <div class="flex gap-2 mt-4">
        <button type="submit" class="bg-blue-600 text-white rounded px-4 py-2 text-sm hover:bg-blue-700">Simpan</button>
        <button type="button" onclick="document.getElementById('modal-token').classList.add('hidden')"
                class="border border-gray-300 rounded px-4 py-2 text-sm hover:bg-gray-50">Batal</button>
      </div>
    </form>
  </div>
</div>

{{-- Modal: Trigger Scrape --}}
<div id="modal-scrape" class="hidden fixed inset-0 bg-black/40 flex items-center justify-center z-50">
  <div class="bg-white rounded-xl shadow-lg p-6 w-full max-w-sm">
    <h2 class="font-semibold text-base mb-4">Scrape Data Transaksi</h2>
    <form action="{{ route('dashboard.scrape') }}" method="POST">
      @csrf
      <div class="space-y-3">
        <div>
          <label class="block text-xs text-gray-500 mb-1">ID Pangkalan</label>
          <input name="pangkalan_id" class="w-full border border-gray-300 rounded px-3 py-2 text-sm"
                 placeholder="mis: PKL-001">
        </div>
        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="block text-xs text-gray-500 mb-1">Dari</label>
            <input type="date" name="from" value="{{ now()->startOfMonth()->toDateString() }}"
                   class="w-full border border-gray-300 rounded px-3 py-2 text-sm" required>
          </div>
          <div>
            <label class="block text-xs text-gray-500 mb-1">Sampai</label>
            <input type="date" name="to" value="{{ now()->toDateString() }}"
                   class="w-full border border-gray-300 rounded px-3 py-2 text-sm" required>
          </div>
        </div>
      </div>
      <div class="flex gap-2 mt-4">
        <button type="submit" class="bg-blue-600 text-white rounded px-4 py-2 text-sm hover:bg-blue-700">Jalankan</button>
        <button type="button" onclick="document.getElementById('modal-scrape').classList.add('hidden')"
                class="border border-gray-300 rounded px-4 py-2 text-sm hover:bg-gray-50">Batal</button>
      </div>
    </form>
  </div>
</div>

@stack('scripts')
</body>
</html>
