<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\TokenCaptureController;
use App\Http\Controllers\TokenInputController;
use App\Http\Controllers\BatchScrapeController;
use App\Http\Controllers\AkunPangkalanController;
use Illuminate\Support\Facades\Route;

Route::prefix('dashboard')->name('dashboard.')->group(function () {

    // Dashboard utama
    Route::get('/',           [DashboardController::class, 'index'])->name('index');
    Route::get('/nik',        [DashboardController::class, 'nikList'])->name('nik.list');
    Route::get('/nik/detail', [DashboardController::class, 'nikDetail'])->name('nik.detail');
    Route::get('/export/csv', [DashboardController::class, 'exportCsv'])->name('export.csv');
    Route::post('/scrape',    [DashboardController::class, 'triggerScrape'])->name('scrape');

    // Token manual
    Route::get('/token/input',     [TokenInputController::class, 'index'])->name('token.input');
    Route::post('/token/input',    [TokenInputController::class, 'store'])->name('token.input.store');
    Route::post('/token/rescrape', [TokenInputController::class, 'rescrape'])->name('token.rescrape');
    Route::post('/token',          [DashboardController::class, 'saveToken'])->name('token.save');

    // ── CRUD Akun Pangkalan ──────────────────────────────────────
    Route::get('/akun',                  [AkunPangkalanController::class, 'index'])->name('akun.index');
    Route::post('/akun',                 [AkunPangkalanController::class, 'store'])->name('akun.store');
    Route::get('/akun/{id}/edit',        [AkunPangkalanController::class, 'edit'])->name('akun.edit');
    Route::put('/akun/{id}',             [AkunPangkalanController::class, 'update'])->name('akun.update');
    Route::delete('/akun/{id}',          [AkunPangkalanController::class, 'destroy'])->name('akun.destroy');
    Route::patch('/akun/{id}/toggle',    [AkunPangkalanController::class, 'toggleActive'])->name('akun.toggle');
    Route::post('/akun/scrape-all',      [AkunPangkalanController::class, 'scrapeAll'])->name('akun.scrape-all');
    Route::post('/akun/{id}/scrape',     [AkunPangkalanController::class, 'scrapeOne'])->name('akun.scrape-one');
    Route::get('/akun/status',           [AkunPangkalanController::class, 'statusApi'])->name('akun.status');

    // Batch scrape (halaman detail)
    Route::get('/batch',           [BatchScrapeController::class, 'index'])->name('batch.index');
    Route::post('/batch/run',      [BatchScrapeController::class, 'run'])->name('batch.run');
    Route::post('/batch/accounts', [BatchScrapeController::class, 'updateAccounts'])->name('batch.accounts');
    Route::get('/batch/status',    [BatchScrapeController::class, 'status'])->name('batch.status');
    Route::get('/batch/status-api',[BatchScrapeController::class, 'statusApi'])->name('batch.status-api');
});

Route::match(['OPTIONS','POST'], '/dashboard/token/capture', [TokenCaptureController::class, 'capture'])
    ->name('token.capture')
    ->withoutMiddleware([\Illuminate\Foundation\Http\Middleware\VerifyCsrfToken::class]);

Route::get('/', fn() => redirect()->route('dashboard.index'));
