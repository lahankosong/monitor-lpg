<?php

namespace App\Http\Controllers;

use App\Models\PangkalanSession;
use App\Models\PangkalanToken;
use App\Models\ScrapeLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;
use Symfony\Component\Process\Process;

class AkunPangkalanController extends Controller
{
    private string $pythonPath;
    private string $scriptsPath;
    private string $accountsPath;

    public function __construct()
    {
        $this->pythonPath   = env('PYTHON_PATH', 'python');
        $this->scriptsPath  = base_path('scripts');
        $this->accountsPath = base_path('scripts/accounts.json');
    }

    // ── CRUD Akun ─────────────────────────────────────────────────

    /**
     * Halaman utama — daftar akun + tombol scrape
     */
    public function index()
    {
        $akuns = PangkalanSession::orderBy('label')->get()->map(function ($s) {
            $token   = PangkalanToken::where('pangkalan_id', $s->pangkalan_id)->first();
            $lastLog = ScrapeLog::where('pangkalan_id', $s->pangkalan_id)
                ->latest('scraped_at')->first();

            return [
                'id'             => $s->id,
                'pangkalan_id'   => $s->pangkalan_id,
                'label'          => $s->label,
                'username'       => $s->username,
                'registration_id'=> $s->registration_id,
                'has_password'   => ! empty($s->password_encrypted),
                'token_valid'    => $token?->token_expires_at?->isFuture() ?? false,
                'token_expires'  => $token?->token_expires_at?->format('H:i d/m'),
                'last_scrape'    => $lastLog?->scraped_at?->format('d/m/Y H:i'),
                'last_status'    => $lastLog?->status,
                'last_saved'     => $lastLog?->records_saved ?? 0,
                'is_active'      => $s->is_active,
            ];
        });

        $isRunning  = Cache::get('batch_scrape_running', false);
        $lastResult = Cache::get('batch_scrape_last_result');
        $progress   = Cache::get('batch_scrape_progress', []);

        return view('dashboard.akun-pangkalan', compact(
            'akuns', 'isRunning', 'lastResult', 'progress'
        ));
    }

    /**
     * Simpan akun baru
     */
    public function store(Request $request)
    {
        $request->validate([
            'label'    => 'required|string|max:100',
            'username' => 'required|string|max:100|unique:pangkalan_sessions,username',
            'password' => 'required|string|min:4',
        ]);

        PangkalanSession::create([
            'pangkalan_id'       => 'pending_' . md5($request->username . time()),
            'label'              => $request->label,
            'username'           => $request->username,
            'password_encrypted' => Crypt::encryptString($request->password),
            'is_active'          => true,
        ]);

        // Sync ke accounts.json
        $this->syncAccountsJson();

        return back()->with('success', "Akun '{$request->label}' berhasil ditambahkan.");
    }

    /**
     * Form edit akun
     */
    public function edit(int $id)
    {
        $akun = PangkalanSession::findOrFail($id);
        return view('dashboard.akun-edit', compact('akun'));
    }

    /**
     * Update akun
     */
    public function update(Request $request, int $id)
    {
        $akun = PangkalanSession::findOrFail($id);

        $request->validate([
            'label'    => 'required|string|max:100',
            'username' => 'required|string|max:100|unique:pangkalan_sessions,username,' . $id,
            'password' => 'nullable|string|min:4',
        ]);

        $data = [
            'label'     => $request->label,
            'username'  => $request->username,
            'is_active' => $request->boolean('is_active', true),
        ];

        if ($request->filled('password')) {
            $data['password_encrypted'] = Crypt::encryptString($request->password);
        }

        $akun->update($data);

        // Update label di token juga
        PangkalanToken::where('pangkalan_id', $akun->pangkalan_id)
            ->update(['label' => $request->label]);

        // Sync ke accounts.json
        $this->syncAccountsJson();

        return redirect()->route('dashboard.akun.index')
            ->with('success', "Akun '{$request->label}' berhasil diperbarui.");
    }

    /**
     * Hapus akun
     */
    public function destroy(int $id)
    {
        $akun = PangkalanSession::findOrFail($id);
        $label = $akun->label;

        PangkalanToken::where('pangkalan_id', $akun->pangkalan_id)->delete();
        ScrapeLog::where('pangkalan_id', $akun->pangkalan_id)->delete();
        $akun->delete();

        $this->syncAccountsJson();

        return back()->with('success', "Akun '{$label}' berhasil dihapus.");
    }

    /**
     * Toggle aktif/nonaktif
     */
    public function toggleActive(int $id)
    {
        $akun = PangkalanSession::findOrFail($id);
        $akun->update(['is_active' => ! $akun->is_active]);
        $this->syncAccountsJson();

        $status = $akun->is_active ? 'diaktifkan' : 'dinonaktifkan';
        return back()->with('success', "Akun '{$akun->label}' {$status}.");
    }

    // ── Scraping ──────────────────────────────────────────────────

    /**
     * Scrape SEMUA akun aktif — satu klik dari dashboard
     * Jalankan sebagai background process agar tidak timeout
     */
    public function scrapeAll(Request $request)
    {
        $request->validate([
            'from' => 'required|date',
            'to'   => 'required|date|after_or_equal:from',
        ]);

        if (Cache::get('batch_scrape_running')) {
            return back()->withErrors(['msg' => 'Proses sedang berjalan. Tunggu selesai.']);
        }

        // Sync accounts.json dulu
        $this->syncAccountsJson();

        $accounts = $this->loadAccounts();
        if (empty($accounts)) {
            return back()->withErrors(['msg' => 'Tidak ada akun aktif untuk di-scrape.']);
        }

        // Tandai running
        Cache::put('batch_scrape_running', true, now()->addHours(2));
        Cache::forget('batch_scrape_last_result');
        Cache::forget('batch_scrape_progress');

        // Jalankan Artisan command sebagai background process
        $artisan = base_path('artisan');
        $cmd = sprintf(
            'start /B php %s batch:scrape --from=%s --to=%s',
            escapeshellarg($artisan),
            escapeshellarg($request->from),
            escapeshellarg($request->to)
        );

        pclose(popen($cmd, 'r'));

        Log::info("[AkunPangkalan] Batch scrape dimulai background: {$request->from} s/d {$request->to}");

        return redirect()->route('dashboard.akun.index')
            ->with('success', "Batch scraping dimulai untuk {$request->from} s/d {$request->to}. Halaman akan update otomatis.");
    }

    /**
     * Scrape SATU akun — dipanggil via AJAX, return JSON progress
     */
    public function scrapeOne(Request $request, int $id)
    {
        $akun = PangkalanSession::findOrFail($id);

        $from = $request->input('from', now()->toDateString());
        $to   = $request->input('to',   now()->toDateString());

        // Sync accounts.json dengan hanya akun ini
        $accounts = [[
            'label' => $akun->label,
            'email' => $akun->username,
            'pin'   => $akun->password, // getter terdekripsi
        ]];

        $tempAccountFile = storage_path('app/temp_account.json');
        file_put_contents($tempAccountFile, json_encode($accounts, JSON_PRETTY_PRINT));

        $resultFile = storage_path('app/single_result_' . $id . '.json');
        if (file_exists($resultFile)) unlink($resultFile);

        $scriptPath = $this->scriptsPath . '/auto_login_batch.py';

        $cmd = sprintf(
            'set PYTHONUNBUFFERED=1 && %s %s --accounts %s --from %s --to %s --output %s 2>&1',
            escapeshellcmd($this->pythonPath),
            escapeshellarg($scriptPath),
            escapeshellarg($tempAccountFile),
            escapeshellarg($from),
            escapeshellarg($to),
            escapeshellarg($resultFile),
        );

        set_time_limit(120); // 2 menit per akun
        exec($cmd);

        if (! file_exists($resultFile)) {
            return response()->json(['success' => false, 'message' => 'Script gagal dijalankan']);
        }

        $result = json_decode(file_get_contents($resultFile), true);

        if (! $result || empty($result['results'])) {
            return response()->json(['success' => false, 'message' => 'Hasil tidak valid']);
        }

        // Import ke database
        $controller = app(\App\Http\Controllers\BatchScrapeController::class);
        foreach ($result['results'] as &$r) {
            $r['from'] = $from;
            $r['to']   = $to;
        }
        $stats = $controller->importResult($resultFile);

        return response()->json([
            'success' => true,
            'saved'   => $stats['total_baru'],
            'message' => "{$akun->label}: {$stats['total_baru']} transaksi baru disimpan",
        ]);
    }

    /**
     * API status polling untuk halaman akun
     */
    public function statusApi()
    {
        return response()->json([
            'running'     => Cache::get('batch_scrape_running', false),
            'progress'    => Cache::get('batch_scrape_progress', []),
            'last_result' => Cache::get('batch_scrape_last_result'),
        ]);
    }

    // ── Helpers ───────────────────────────────────────────────────

    /**
     * Sync database → accounts.json (selalu up to date)
     */
    private function syncAccountsJson(): void
    {
        $accounts = PangkalanSession::where('is_active', true)
            ->orderBy('label')
            ->get()
            ->map(function ($s) {
                return [
                    'label' => $s->label,
                    'email' => $s->username,
                    'pin'   => $s->password, // getter terdekripsi
                ];
            })
            ->filter(fn($a) => $a['pin'] !== null) // skip yang passwordnya rusak
            ->values()
            ->toArray();

        if (! is_dir($this->scriptsPath)) {
            mkdir($this->scriptsPath, 0755, true);
        }

        file_put_contents(
            $this->accountsPath,
            json_encode($accounts, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
        );
    }

    private function loadAccounts(): array
    {
        if (! file_exists($this->accountsPath)) return [];
        return json_decode(file_get_contents($this->accountsPath), true) ?? [];
    }
}
