@extends('layouts.app')
@section('title', 'Kelola Akun Pangkalan')

@section('content')

{{-- Header --}}
<div class="flex items-center justify-between mb-5 flex-wrap gap-3">
  <div>
    <h1 class="text-lg font-semibold">Kelola Akun Pangkalan</h1>
    <p class="text-xs text-gray-500 mt-0.5">CRUD akun login + scraping data transaksi satu klik</p>
  </div>
  <button onclick="document.getElementById('modal-tambah').classList.remove('hidden')"
          class="text-sm bg-blue-600 text-white rounded-lg px-4 py-2 hover:bg-blue-700">
    + Tambah Akun
  </button>
</div>

@if(session('success'))
<div class="bg-green-50 border border-green-200 rounded-xl p-3 mb-4 text-sm text-green-800">
  ✓ {{ session('success') }}
</div>
@endif
@if($errors->any())
<div class="bg-red-50 border border-red-200 rounded-xl p-3 mb-4 text-sm text-red-800">
  @foreach($errors->all() as $e)✗ {{ $e }}<br>@endforeach
</div>
@endif

{{-- Status batch berjalan --}}
<div id="batchStatus" class="{{ $isRunning ? '' : 'hidden' }} bg-blue-50 border border-blue-200 rounded-xl p-4 mb-5">
  <div class="flex items-center gap-3">
    <div class="animate-spin text-xl">⚙️</div>
    <div class="flex-1">
      <p class="font-medium text-sm text-blue-800">Batch scraping sedang berjalan...</p>
      <div class="mt-2 bg-blue-100 rounded-full h-2 overflow-hidden">
        <div id="progressBar" class="bg-blue-500 h-2 rounded-full transition-all duration-500"
             style="width: {{ isset($progress['total']) ? round($progress['current']/$progress['total']*100) : 0 }}%"></div>
      </div>
      <p id="progressText" class="text-xs text-blue-600 mt-1">
        {{ isset($progress['current']) ? "{$progress['current']}/{$progress['total']} — {$progress['label']}" : 'Memulai...' }}
      </p>
    </div>
  </div>
</div>

{{-- Hasil batch terakhir --}}
@if($lastResult)
<div class="bg-green-50 border border-green-200 rounded-xl p-4 mb-5">
  <p class="font-medium text-sm text-green-800 mb-2">✓ Batch scrape selesai</p>
  <div class="flex gap-6 text-sm">
    <span class="text-green-700">Berhasil: <strong>{{ $lastResult['berhasil'] }}</strong></span>
    <span class="text-red-600">Gagal: <strong>{{ $lastResult['gagal'] }}</strong></span>
    <span class="text-blue-700">Transaksi baru: <strong>{{ $lastResult['total_baru'] }}</strong></span>
  </div>
</div>
@endif

{{-- Form scrape semua --}}
<div class="bg-white rounded-xl border border-gray-200 p-4 mb-5">
  <div class="flex items-center gap-4 flex-wrap">
    <p class="font-medium text-sm">Scrape Semua Akun Aktif:</p>
    <form action="{{ route('dashboard.akun.scrape-all') }}" method="POST"
          class="flex items-center gap-2 flex-1" id="formScrapeAll">
      @csrf
      <input type="date" name="from" id="globalFrom"
             value="{{ now()->startOfWeek()->toDateString() }}"
             class="border border-gray-300 rounded-lg px-3 py-1.5 text-sm">
      <span class="text-gray-400 text-xs">s/d</span>
      <input type="date" name="to" id="globalTo"
             value="{{ now()->toDateString() }}"
             class="border border-gray-300 rounded-lg px-3 py-1.5 text-sm">
      <button type="submit" id="btnScrapeAll"
              {{ $isRunning ? 'disabled' : '' }}
              class="bg-green-600 text-white rounded-lg px-4 py-1.5 text-sm hover:bg-green-700
                     disabled:opacity-40 disabled:cursor-not-allowed">
        🚀 Scrape Semua ({{ $akuns->where('is_active', true)->count() }} akun)
      </button>
    </form>
  </div>
</div>

{{-- Tabel akun --}}
<div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500 uppercase tracking-wide">
      <tr>
        <th class="text-left px-4 py-3">Nama Pangkalan</th>
        <th class="text-left px-4 py-3">Username/Email</th>
        <th class="text-center px-4 py-3">Token</th>
        <th class="text-right px-4 py-3">Scrape Terakhir</th>
        <th class="text-right px-4 py-3">Txn</th>
        <th class="text-center px-4 py-3">Aktif</th>
        <th class="px-4 py-3 text-right">Aksi</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-gray-100" id="akunTable">
      @forelse($akuns as $a)
      <tr class="hover:bg-gray-50 {{ ! $a['is_active'] ? 'opacity-50' : '' }}" id="row-{{ $a['id'] }}">
        <td class="px-4 py-3 font-medium">
          {{ $a['label'] }}
          @if($a['registration_id'])
            <span class="text-xs text-gray-400 font-normal block">{{ $a['registration_id'] }}</span>
          @endif
        </td>
        <td class="px-4 py-3 text-gray-600 text-xs">{{ $a['username'] }}</td>
        <td class="px-4 py-3 text-center">
          @if($a['token_valid'])
            <span class="badge-aman">Aktif s/d {{ $a['token_expires'] }}</span>
          @else
            <span class="text-xs text-gray-400">—</span>
          @endif
        </td>
        <td class="px-4 py-3 text-right text-xs text-gray-500">
          @if($a['last_scrape'])
            {{ $a['last_scrape'] }}
            <span class="{{ $a['last_status']==='success' ? 'text-green-600':'text-red-500' }}">
              ({{ $a['last_status'] }})
            </span>
          @else
            <span class="text-gray-300">Belum pernah</span>
          @endif
        </td>
        <td class="px-4 py-3 text-right text-xs font-medium">{{ $a['last_saved'] ?: '—' }}</td>
        <td class="px-4 py-3 text-center">
          <form action="{{ route('dashboard.akun.toggle', $a['id']) }}" method="POST" class="inline">
            @csrf @method('PATCH')
            <button type="submit"
                    class="text-xs {{ $a['is_active'] ? 'text-green-600' : 'text-gray-400' }} hover:underline">
              {{ $a['is_active'] ? '● Aktif' : '○ Nonaktif' }}
            </button>
          </form>
        </td>
        <td class="px-4 py-3 text-right">
          <div class="flex items-center justify-end gap-2">
            {{-- Scrape satu akun via AJAX --}}
            @if($a['is_active'])
            <button onclick="scrapeOne({{ $a['id'] }}, '{{ $a['label'] }}')"
                    class="text-xs bg-blue-600 text-white rounded px-3 py-1 hover:bg-blue-700
                           scrape-btn" data-id="{{ $a['id'] }}">
              Scrape
            </button>
            @endif
            <a href="{{ route('dashboard.akun.edit', $a['id']) }}"
               class="text-xs text-gray-500 hover:text-gray-800">Edit</a>
            <form action="{{ route('dashboard.akun.destroy', $a['id']) }}" method="POST"
                  onsubmit="return confirm('Hapus akun {{ $a['label'] }}?')" class="inline">
              @csrf @method('DELETE')
              <button type="submit" class="text-xs text-red-400 hover:text-red-600">Hapus</button>
            </form>
          </div>
        </td>
      </tr>
      @empty
      <tr>
        <td colspan="7" class="px-4 py-10 text-center text-gray-400">
          Belum ada akun. Klik "+ Tambah Akun" untuk mulai.
        </td>
      </tr>
      @endforelse
    </tbody>
  </table>
</div>

{{-- Modal Tambah Akun --}}
<div id="modal-tambah" class="hidden fixed inset-0 bg-black/40 flex items-center justify-center z-50">
  <div class="bg-white rounded-xl shadow-lg p-6 w-full max-w-md">
    <h2 class="font-semibold text-base mb-4">Tambah Akun Pangkalan</h2>
    <form action="{{ route('dashboard.akun.store') }}" method="POST">
      @csrf
      <div class="space-y-3">
        <div>
          <label class="block text-xs text-gray-500 mb-1">Nama Pangkalan *</label>
          <input name="label" required autofocus
                 class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500"
                 placeholder="mis: Pangkalan Bu Sari RT 05">
        </div>
        <div>
          <label class="block text-xs text-gray-500 mb-1">Email / Username *</label>
          <input name="username" required type="email"
                 class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500"
                 placeholder="email@gmail.com">
        </div>
        <div>
          <label class="block text-xs text-gray-500 mb-1">Password / PIN *</label>
          <input name="password" required type="password"
                 class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500"
                 placeholder="Password atau PIN MyPertamina">
        </div>
      </div>
      <div class="flex gap-2 mt-4">
        <button type="submit"
                class="bg-blue-600 text-white rounded-lg px-4 py-2 text-sm hover:bg-blue-700">
          Simpan
        </button>
        <button type="button"
                onclick="document.getElementById('modal-tambah').classList.add('hidden')"
                class="border border-gray-300 rounded-lg px-4 py-2 text-sm hover:bg-gray-50">
          Batal
        </button>
      </div>
    </form>
  </div>
</div>

@endsection

@push('scripts')
<script>
// ── Scrape satu akun via AJAX ─────────────────────────────────
async function scrapeOne(id, label) {
  const btn  = document.querySelector(`.scrape-btn[data-id="${id}"]`);
  const from = document.getElementById('globalFrom').value;
  const to   = document.getElementById('globalTo').value;

  btn.disabled    = true;
  btn.textContent = '⏳';

  try {
    const res = await fetch(`/dashboard/akun/${id}/scrape`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]').content,
        'Accept': 'application/json',
      },
      body: JSON.stringify({ from, to }),
    });

    const data = await res.json();

    if (data.success) {
      btn.textContent = '✓';
      btn.classList.replace('bg-blue-600', 'bg-green-600');
      // Tampilkan notif kecil
      showToast(`✓ ${data.message}`, 'green');
    } else {
      btn.textContent = '✗';
      btn.classList.replace('bg-blue-600', 'bg-red-500');
      showToast(`✗ ${label}: ${data.message}`, 'red');
    }
  } catch (e) {
    btn.textContent = '✗';
    showToast(`✗ Koneksi error: ${e.message}`, 'red');
  } finally {
    setTimeout(() => {
      btn.disabled    = false;
      btn.textContent = 'Scrape';
      btn.classList.replace('bg-green-600', 'bg-blue-600');
      btn.classList.replace('bg-red-500',   'bg-blue-600');
    }, 3000);
  }
}

// ── Toast notifikasi ──────────────────────────────────────────
function showToast(msg, color = 'green') {
  const toast = document.createElement('div');
  toast.className = `fixed bottom-6 right-6 z-50 px-4 py-3 rounded-xl shadow-lg text-sm font-medium
    ${color === 'green' ? 'bg-green-600 text-white' : 'bg-red-600 text-white'}`;
  toast.textContent = msg;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}

// ── Polling status batch berjalan ────────────────────────────
@if($isRunning)
function pollStatus() {
  fetch('{{ route("dashboard.akun.status") }}')
    .then(r => r.json())
    .then(data => {
      if (data.progress?.total) {
        const pct = Math.round(data.progress.current / data.progress.total * 100);
        document.getElementById('progressBar').style.width = pct + '%';
        document.getElementById('progressText').textContent =
          `${data.progress.current}/${data.progress.total} — ${data.progress.label}`;
      }
      if (! data.running) {
        // Selesai — reload
        window.location.reload();
      }
    }).catch(() => {});
}
setInterval(pollStatus, 3000);
pollStatus();
@endif
</script>
@endpush
