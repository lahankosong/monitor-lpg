/**
 * Monitor LPG - Background Service Worker
 * Menangkap Bearer token dari request ke api-map.my-pertamina.id
 * dan mengirimkannya ke Laravel di localhost:8000
 */

const LARAVEL_URL = 'http://localhost:8000';
const TARGET_HOST = 'api-map.my-pertamina.id';

let lastSentToken = null;
let lastSentPangkalanId = null;

// Intersep semua request ke MyPertamina API
chrome.webRequest.onBeforeSendHeaders.addListener(
  async (details) => {
    const authHeader = details.requestHeaders?.find(
      h => h.name.toLowerCase() === 'authorization'
    );

    if (!authHeader?.value?.startsWith('Bearer ')) return;

    const token     = authHeader.value.replace('Bearer ', '').trim();
    const pangkalan = decodeJwt(token);

    // Skip jika token sama persis yang sudah dikirim
    if (token === lastSentToken) return;

    lastSentToken      = token;
    lastSentPangkalanId = pangkalan.id;

    console.log('[LPG Monitor] Token terdeteksi untuk pangkalan:', pangkalan.id);
    await kirimKeLaravel(token, pangkalan);
  },
  { urls: [`https://${TARGET_HOST}/*`] },
  ['requestHeaders']
);

function decodeJwt(token) {
  try {
    const payload = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
    return {
      id:       payload.sub  || 'unknown',
      expAt:    payload.exp  ? new Date(payload.exp  * 1000).toISOString() : null,
      issuedAt: payload.iat  ? new Date(payload.iat  * 1000).toISOString() : null,
    };
  } catch (e) {
    return { id: 'unknown', expAt: null, issuedAt: null };
  }
}

async function kirimKeLaravel(token, pangkalan) {
  try {
    // Kirim langsung via fetch — tidak perlu CSRF cookie
    // karena route sudah dikecualikan dari CSRF di bootstrap/app.php
    const res = await fetch(`${LARAVEL_URL}/dashboard/token/capture`, {
      method: 'POST',
      headers: {
        'Content-Type':     'application/json',
        'Accept':           'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        'X-Extension-Key':  'lpg-monitor-extension', // identifikasi dari extension
      },
      body: JSON.stringify({
        token:        token,
        pangkalan_id: pangkalan.id,
        expires_at:   pangkalan.expAt,
        issued_at:    pangkalan.issuedAt,
      }),
    });

    let data = {};
    try { data = await res.json(); } catch(e) {}

    if (res.ok && data.success) {
      console.log('[LPG Monitor] ✓ Token terkirim:', data.message);

      // Increment counter pangkalan
      const stored = await chrome.storage.local.get(['captureCount', 'pangkalanList']);
      const list   = stored.pangkalanList || [];
      if (!list.includes(pangkalan.id)) list.push(pangkalan.id);

      await chrome.storage.local.set({
        captureCount:  list.length,
        pangkalanList: list,
        lastCapture: {
          pangkalanId: pangkalan.id,
          label:       data.label || pangkalan.id,
          expAt:       pangkalan.expAt,
          sentAt:      new Date().toISOString(),
          status:      'success',
          scraped:     data.scraped,
        }
      });

      // Notifikasi
      chrome.notifications.create({
        type:    'basic',
        iconUrl: 'icon48.png',
        title:   data.scraped ? '✓ Token + Data Tersimpan' : '✓ Token Tersimpan',
        message: `${data.label || pangkalan.id} — ${list.length} pangkalan tercapture`,
      });

    } else {
      throw new Error(data.message || `HTTP ${res.status}`);
    }

  } catch (err) {
    console.error('[LPG Monitor] ✗ Gagal kirim:', err.message);

    const isLaravelMati = err.message.includes('fetch') || err.message.includes('Failed');

    await chrome.storage.local.set({
      lastCapture: {
        pangkalanId: pangkalan.id,
        sentAt:      new Date().toISOString(),
        status:      isLaravelMati ? 'error' : 'failed',
        error:       isLaravelMati
          ? 'Laravel tidak aktif — jalankan: php artisan serve'
          : err.message,
      }
    });

    chrome.notifications.create({
      type:    'basic',
      iconUrl: 'icon48.png',
      title:   '✗ Gagal Kirim Token',
      message: isLaravelMati ? 'Laravel tidak aktif' : err.message,
    });
  }
}
