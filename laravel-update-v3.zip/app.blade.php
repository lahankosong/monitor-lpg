<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>Monitor LPG Subsidi – @yield('title', 'Dashboard')</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<style>
  .badge-alert { background:#FEE2E2;color:#991B1B;font-size:11px;padding:2px 8px;border-radius:99px;font-weight:500;display:inline-block; }
  .badge-warn  { background:#FEF3C7;color:#92400E;font-size:11px;padding:2px 8px;border-radius:99px;font-weight:500;display:inline-block; }
  .badge-aman  { background:#D1FAE5;color:#065F46;font-size:11px;padding:2px 8px;border-radius:99px;font-weight:500;display:inline-block; }
  .badge-new   { background:#DBEAFE;color:#1E40AF;font-size:11px;padding:2px 8px;border-radius:99px;font-weight:500;display:inline-block; }
</style>
</head>
<body class="bg-gray-50 text-gray-900 text-sm">

<nav class="bg-white border-b border-gray-200 px-6 py-3 flex items-center gap-6">
  <span class="font-semibold text-base text-gray-800">⛽ Monitor LPG Subsidi</span>
  <a href="{{ route('dashboard.index') }}"
     class="text-gray-600 hover:text-gray-900 {{ request()->routeIs('dashboard.index') ? 'font-medium text-gray-900':'' }}">
    Dashboard
  </a>
  <a href="{{ route('dashboard.nik.list') }}"
     class="text-gray-600 hover:text-gray-900 {{ request()->routeIs('dashboard.nik.*') ? 'font-medium text-gray-900':'' }}">
    Monitor NIK
  </a>
  {{-- Link ke halaman daftar pangkalan --}}
  <a href="{{ route('dashboard.pangkalan.list') }}"
     class="text-gray-600 hover:text-gray-900 {{ request()->routeIs('dashboard.pangkalan.*') ? 'font-medium text-gray-900':'' }}">
    Pangkalan
    @php $jumlahPangkalan = \App\Models\PangkalanToken::count(); @endphp
    @if($jumlahPangkalan > 0)
      <span class="ml-1 bg-gray-100 text-gray-500 text-xs px-1.5 py-0.5 rounded-full">{{ $jumlahPangkalan }}</span>
    @endif
  </a>

  <div class="ml-auto flex items-center gap-3">
    @php
      $activeTokens = \App\Models\PangkalanToken::where('is_active', true)
        ->where(function($q){ $q->whereNull('token_expires_at')->orWhere('token_expires_at', '>', now()); })
        ->count();
      $expiredTokens = \App\Models\PangkalanToken::where('is_active', true)
        ->where('token_expires_at', '<=', now())
        ->count();
    @endphp
    @if($activeTokens > 0)
      <span class="text-xs text-green-600">● {{ $activeTokens }} token aktif</span>
    @endif
    @if($expiredTokens > 0)
      <span class="text-xs text-red-500">● {{ $expiredTokens }} expired</span>
    @endif
    <button onclick="document.getElementById('modal-token').classList.remove('hidden')"
            class="text-xs border border-gray-300 rounded px-3 py-1.5 hover:bg-gray-50">
      + Token Manual
    </button>
    <button onclick="document.getElementById('modal-scrape').classList.remove('hidden')"
            class="text-xs bg-blue-600 text-white rounded px-3 py-1.5 hover:bg-blue-700">
      Scrape Data
    </button>
  </div>
</nav>

@if(session('success'))
<div class="bg-green-50 border-b border-green-200 text-green-800 text-xs px-6 py-2">✓ {{ session('success') }}</div>
@endif
@if($errors->any())
<div class="bg-red-50 border-b border-red-200 text-red-800 text-xs px-6 py-2">
  @foreach($errors->all() as $e) ✗ {{ $e }}<br> @endforeach
</div>
@endif

<main class="p-6">@yield('content')</main>

{{-- Modal: Token Manual --}}
<div id="modal-token" class="hidden fixed inset-0 bg-black/40 flex items-center justify-center z-50">
  <div class="bg-white rounded-xl shadow-lg p-6 w-full max-w-md">
    <h2 class="font-semibold text-base mb-1">Tambah Token Manual</h2>
    <p class="text-xs text-gray-400 mb-4">
      Gunakan ini jika Chrome Extension belum berjalan.
      ID Pangkalan diekstrak otomatis dari JWT token.
    </p>
    <form action="{{ route('dashboard.token.save') }}" method="POST">
      @csrf
      <div class="space-y-3">
        <div>
          <label class="block text-xs text-gray-500 mb-1">Nama Pangkalan (opsional)</label>
          <input name="label" class="w-full border border-gray-300 rounded px-3 py-2 text-sm"
                 placeholder="mis: Pangkalan Bu Sari RT 05">
        </div>
        <div>
          <label class="block text-xs text-gray-500 mb-1">Bearer Token</label>
          <textarea name="token" rows="4"
                    class="w-full border border-gray-300 rounded px-3 py-2 text-xs font-mono"
                    placeholder="F12 → Network → filter: api-map → klik request → Headers → copy nilai Authorization" required></textarea>
          <p class="text-xs text-amber-600 mt-1">⚠ Token berlaku ±15 menit sejak login.</p>
        </div>
      </div>
      <div class="flex gap-2 mt-4">
        <button type="submit" class="bg-blue-600 text-white rounded px-4 py-2 text-sm hover:bg-blue-700">Simpan & Scrape</button>
        <button type="button" onclick="document.getElementById('modal-token').classList.add('hidden')"
                class="border border-gray-300 rounded px-4 py-2 text-sm hover:bg-gray-50">Batal</button>
      </div>
    </form>
  </div>
</div>

{{-- Modal: Scrape Data --}}
<div id="modal-scrape" class="hidden fixed inset-0 bg-black/40 flex items-center justify-center z-50">
  <div class="bg-white rounded-xl shadow-lg p-6 w-full max-w-sm">
    <h2 class="font-semibold text-base mb-1">Scrape Data Transaksi</h2>
    <p class="text-xs text-gray-400 mb-4">Menggunakan token aktif yang tersimpan.</p>
    <form action="{{ route('dashboard.scrape') }}" method="POST">
      @csrf
      <div class="grid grid-cols-2 gap-2">
        <div>
          <label class="block text-xs text-gray-500 mb-1">Dari</label>
          <input type="date" name="from" value="{{ now()->startOfMonth()->toDateString() }}"
                 class="w-full border border-gray-300 rounded px-3 py-2 text-sm" required>
        </div>
        <div>
          <label class="block text-xs text-gray-500 mb-1">Sampai</label>
          <input type="date" name="to" value="{{ now()->toDateString() }}"
                 class="w-full border border-gray-300 rounded px-3 py-2 text-sm" required>
        </div>
      </div>
      <div class="flex gap-2 mt-4">
        <button type="submit" class="bg-blue-600 text-white rounded px-4 py-2 text-sm hover:bg-blue-700">Jalankan</button>
        <button type="button" onclick="document.getElementById('modal-scrape').classList.add('hidden')"
                class="border border-gray-300 rounded px-4 py-2 text-sm hover:bg-gray-50">Batal</button>
      </div>
    </form>
  </div>
</div>

@stack('scripts')
</body>
</html>
