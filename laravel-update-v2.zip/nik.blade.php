@extends('layouts.app')
@section('title', 'Monitor NIK')

@section('content')

<div class="flex items-center justify-between mb-5 flex-wrap gap-3">
  <h1 class="text-lg font-semibold">Monitor NIK per Transaksi</h1>
  <form method="GET" class="flex items-center gap-2 flex-wrap">
    <input type="text" name="search" value="{{ $search }}" placeholder="Cari NIK atau nama..."
           class="border border-gray-300 rounded px-2 py-1.5 text-sm w-48">
    <input type="date" name="from" value="{{ $from }}" class="border border-gray-300 rounded px-2 py-1.5 text-sm">
    <input type="date" name="to"   value="{{ $to }}"   class="border border-gray-300 rounded px-2 py-1.5 text-sm">
    <select name="interval" class="border border-gray-300 rounded px-2 py-1.5 text-sm">
      <option value="5"  {{ $minInterval==5  ? 'selected':'' }}>5 hari</option>
      <option value="7"  {{ $minInterval==7  ? 'selected':'' }}>7 hari</option>
      <option value="14" {{ $minInterval==14 ? 'selected':'' }}>14 hari</option>
    </select>
    <select name="status" class="border border-gray-300 rounded px-2 py-1.5 text-sm">
      <option value="">Semua status</option>
      <option value="alert" {{ $filterStatus==='alert' ? 'selected':'' }}>Frekuensi Tinggi</option>
      <option value="warn"  {{ $filterStatus==='warn'  ? 'selected':'' }}>Perlu Pantau</option>
      <option value="aman"  {{ $filterStatus==='aman'  ? 'selected':'' }}>Aman</option>
      <option value="new"   {{ $filterStatus==='new'   ? 'selected':'' }}>Data Baru</option>
    </select>
    <button type="submit" class="bg-gray-800 text-white rounded px-3 py-1.5 text-sm">Filter</button>
    <a href="{{ route('dashboard.export.csv', ['from'=>$from,'to'=>$to]) }}"
       class="border border-gray-300 rounded px-3 py-1.5 text-sm hover:bg-gray-50">CSV</a>
  </form>
</div>

<div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500 uppercase tracking-wide">
      <tr>
        <th class="text-left px-4 py-3">NIK (sensor)</th>
        <th class="text-left px-4 py-3">Nama</th>
        <th class="text-right px-4 py-3">Transaksi</th>
        <th class="text-right px-4 py-3">Tabung</th>
        <th class="text-right px-4 py-3">Terakhir</th>
        <th class="text-right px-4 py-3">Jarak rata²</th>
        <th class="text-left px-4 py-3">Frekuensi</th>
        <th class="text-left px-4 py-3">Status</th>
        <th class="px-4 py-3"></th>
      </tr>
    </thead>
    <tbody class="divide-y divide-gray-100">
      @forelse($nikData as $n)
      @php
        $maxTabung = $nikData->max('total_tabung') ?: 1;
        $pct       = round($n['total_tabung'] / $maxTabung * 100);
        $barColor  = match($n['status']) {
          'alert' => 'bg-red-500',
          'warn'  => 'bg-amber-400',
          'new'   => 'bg-blue-400',
          default => 'bg-green-500',
        };
        $gapColor = ($n['avg_gap'] !== null && $n['avg_gap'] < $minInterval)
          ? 'text-red-600 font-medium' : 'text-gray-600';
      @endphp
      <tr class="hover:bg-gray-50">
        <td class="px-4 py-3 font-mono text-xs text-gray-500">{{ $n['nik'] }}</td>
        <td class="px-4 py-3 font-medium">{{ $n['nama'] }}</td>
        <td class="px-4 py-3 text-right text-gray-600">{{ $n['total_txn'] }}</td>
        <td class="px-4 py-3 text-right font-semibold">{{ $n['total_tabung'] }}</td>
        <td class="px-4 py-3 text-right text-xs text-gray-500">{{ $n['tgl_terakhir'] }}</td>
        <td class="px-4 py-3 text-right {{ $gapColor }}">
          {{ $n['avg_gap'] !== null ? $n['avg_gap'].'h' : '—' }}
        </td>
        <td class="px-4 py-3">
          <div class="flex items-center gap-2">
            <div class="flex-1 bg-gray-100 rounded-full h-1.5 min-w-[48px]">
              <div class="{{ $barColor }} h-1.5 rounded-full" style="width:{{ $pct }}%"></div>
            </div>
            <span class="text-xs text-gray-400 w-8 text-right">{{ $n['total_tabung'] }}</span>
          </div>
        </td>
        <td class="px-4 py-3">
          @switch($n['status'])
            @case('alert') <span class="badge-alert">Frekuensi Tinggi</span> @break
            @case('warn')  <span class="badge-warn">Perlu Pantau</span>      @break
            @case('new')   <span class="badge-new">Data Baru</span>          @break
            @default       <span class="badge-aman">Aman</span>
          @endswitch
          @if(count($n['violations']) > 0)
            <span class="text-xs text-red-500 ml-1">{{ count($n['violations']) }}x !</span>
          @endif
        </td>
        <td class="px-4 py-3 text-right">
          {{-- Gunakan query string karena NIK tersensor tidak aman di URL path --}}
          <a href="{{ route('dashboard.nik.detail', [
                'nik'  => $n['nik'],
                'nama' => $n['nama'],
                'from' => $from,
                'to'   => $to,
                'interval' => $minInterval,
             ]) }}"
             class="text-xs text-blue-600 hover:underline">Detail</a>
        </td>
      </tr>
      @empty
      <tr>
        <td colspan="9" class="px-4 py-10 text-center text-gray-400">
          Tidak ada data. Ubah rentang tanggal atau jalankan scraping terlebih dahulu.
        </td>
      </tr>
      @endforelse
    </tbody>
  </table>
</div>

<p class="text-xs text-gray-400 mt-2">
  {{ $nikData->count() }} individu ·
  Interval min: {{ $minInterval }} hari ·
  {{ $from }} s/d {{ $to }} ·
  <span class="text-gray-300">NIK dikelompokkan berdasarkan NIK sensor + nama</span>
</p>

@endsection
