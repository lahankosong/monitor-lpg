<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // Hapus duplikat yang sudah terlanjur masuk
        // Simpan hanya 1 baris per kombinasi nationality_id + name + transaction_at
        DB::statement('
            DELETE t1 FROM transactions t1
            INNER JOIN transactions t2
            WHERE t1.id > t2.id
              AND t1.nationality_id  = t2.nationality_id
              AND t1.name            = t2.name
              AND t1.transaction_at  = t2.transaction_at
        ');

        // Tambah unique constraint agar tidak bisa duplikat lagi
        // Gunakan kolom transaction_at sampai detik (bukan milidetik)
        Schema::table('transactions', function (Blueprint $table) {
            // Hapus unique lama di customer_report_id (tidak bisa diandalkan)
            $table->dropUnique(['customer_report_id']);

            // Unique constraint yang benar: satu orang tidak mungkin beli
            // di pangkalan yang sama pada detik yang persis sama
            $table->unique(
                ['nationality_id', 'name', 'transaction_at'],
                'uniq_person_time'
            );
        });
    }

    public function down(): void
    {
        Schema::table('transactions', function (Blueprint $table) {
            $table->dropUnique('uniq_person_time');
            $table->unique('customer_report_id');
        });
    }
};
