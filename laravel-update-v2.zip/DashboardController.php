<?php

namespace App\Http\Controllers;

use App\Jobs\ScrapeTransactionsJob;
use App\Models\Transaction;
use App\Models\NikViolation;
use App\Models\DailySummary;
use App\Models\PangkalanToken;
use App\Models\ScrapeLog;
use Carbon\Carbon;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    // ── Dashboard utama ───────────────────────────────────────────

    public function index(Request $request)
    {
        $from        = $request->get('from', now()->startOfMonth()->toDateString());
        $to          = $request->get('to',   now()->toDateString());
        $minInterval = (int) $request->get('interval', 7);

        $nikStatus = Transaction::nikStatusSummary($from, $to, $minInterval);
        $totalNik  = array_sum($nikStatus);

        $summary     = DailySummary::whereBetween('summary_date', [$from, $to])->get();
        $totalSold   = $summary->sum('sold');
        $totalGross  = $summary->sum('gross');
        $totalProfit = $summary->sum('profit');

        $openViolations = NikViolation::unresolved()
            ->orderBy('severity', 'desc')
            ->limit(10)->get();

        $chartDays = collect();
        for ($i = 6; $i >= 0; $i--) {
            $date = now()->subDays($i)->toDateString();
            $chartDays->push([
                'date'  => $date,
                'label' => Carbon::parse($date)->format('d/m'),
                'sold'  => DailySummary::where('summary_date', $date)->sum('sold'),
                'txn'   => Transaction::where('transaction_date', $date)->count(),
            ]);
        }

        $lastScrape  = ScrapeLog::latest('scraped_at')->first();
        $tokenStatus = PangkalanToken::where('is_active', true)->first();

        return view('dashboard.index', compact(
            'nikStatus', 'totalNik', 'from', 'to', 'minInterval',
            'totalSold', 'totalGross', 'totalProfit',
            'openViolations', 'chartDays', 'lastScrape', 'tokenStatus'
        ));
    }

    // ── Daftar semua individu (group by NIK+nama) ─────────────────

    public function nikList(Request $request)
    {
        $from         = $request->get('from', now()->startOfMonth()->toDateString());
        $to           = $request->get('to',   now()->toDateString());
        $minInterval  = (int) $request->get('interval', 7);
        $search       = $request->get('search', '');
        $filterStatus = $request->get('status', '');

        $query = Transaction::dateRange($from, $to)
            ->when($search, fn($q) => $q->where(function ($q) use ($search) {
                $q->where('nationality_id', 'like', "%{$search}%")
                  ->orWhere('name', 'like', "%{$search}%");
            }))
            ->orderBy('transaction_date')
            ->get();

        // Group by NIK+nama — karena customerReportId berbeda tiap transaksi
        $groups = $query->groupBy(fn($t) => $t->nationality_id . '||' . $t->name);

        $nikData = $groups->map(function ($txns) use ($minInterval) {
            $dates  = $txns->pluck('transaction_date')
                ->map(fn($d) => Carbon::parse($d))
                ->sort()->values();

            $gaps       = [];
            $violations = [];
            for ($i = 1; $i < $dates->count(); $i++) {
                $gap = $dates[$i - 1]->diffInDays($dates[$i]);
                $gaps[] = $gap;
                if ($gap < $minInterval) {
                    $violations[] = [
                        'dari'   => $dates[$i - 1]->format('Y-m-d'),
                        'ke'     => $dates[$i]->format('Y-m-d'),
                        'gap'    => $gap,
                        'kurang' => $minInterval - $gap,
                    ];
                }
            }

            $avgGap = count($gaps) ? round(array_sum($gaps) / count($gaps), 1) : null;
            $status = Transaction::analyzeStatus($txns, $minInterval);

            // Kumpulkan semua customerReportId milik orang ini
            $reportIds = $txns->pluck('customer_report_id')->toArray();

            return [
                'nik'          => $txns->first()->nationality_id,
                'nama'         => $txns->first()->name,
                'report_ids'   => $reportIds,           // semua ID transaksi
                'total_txn'    => $txns->count(),
                'total_tabung' => $txns->sum('total'),
                'tgl_pertama'  => $dates->first()?->format('Y-m-d'),
                'tgl_terakhir' => $dates->last()?->format('Y-m-d'),
                'avg_gap'      => $avgGap,
                'violations'   => $violations,
                'status'       => $status,
            ];
        })->values();

        if ($filterStatus) {
            $nikData = $nikData->filter(fn($n) => $n['status'] === $filterStatus)->values();
        }

        $order   = ['alert' => 0, 'warn' => 1, 'new' => 2, 'aman' => 3];
        $nikData = $nikData->sortBy(fn($n) => $order[$n['status']] ?? 9)->values();

        return view('dashboard.nik', compact(
            'nikData', 'from', 'to', 'minInterval', 'search', 'filterStatus'
        ));
    }

    // ── Detail satu individu (via NIK tersensor + nama) ───────────

    public function nikDetail(Request $request)
    {
        $from = $request->get('from', now()->subMonths(3)->toDateString());
        $to   = $request->get('to',   now()->toDateString());
        $nik  = $request->get('nik');
        $nama = $request->get('nama');

        abort_if(! $nik || ! $nama, 400, 'Parameter nik dan nama diperlukan');

        $txns = Transaction::where('nationality_id', $nik)
            ->where('name', $nama)
            ->dateRange($from, $to)
            ->orderBy('transaction_date')
            ->get();

        abort_if($txns->isEmpty(), 404, 'Data tidak ditemukan');

        $minInterval = (int) $request->get('interval', 7);
        $status      = Transaction::analyzeStatus($txns, $minInterval);

        // Hitung gap antar transaksi
        $dates      = $txns->pluck('transaction_date')->map(fn($d) => Carbon::parse($d))->sort()->values();
        $violations = [];
        for ($i = 1; $i < $dates->count(); $i++) {
            $gap = $dates[$i - 1]->diffInDays($dates[$i]);
            if ($gap < $minInterval) {
                $violations[] = ['dari' => $dates[$i - 1]->format('d/m'), 'ke' => $dates[$i]->format('d/m'), 'gap' => $gap];
            }
        }

        return view('dashboard.nik-detail', compact(
            'txns', 'nik', 'nama', 'status', 'violations', 'from', 'to', 'minInterval'
        ));
    }

    // ── Simpan token — ekstrak pangkalan_id dari JWT ──────────────

    public function saveToken(Request $request)
    {
        $request->validate([
            'label' => 'nullable|string|max:100',
            'token' => 'required|string',
        ]);

        $token        = trim(str_replace('Bearer ', '', $request->token));
        $pangkalanId  = null;
        $expireAt     = null;
        $issuedAt     = null;

        // Decode JWT — sub = ID pangkalan, exp = waktu expire
        try {
            $parts   = explode('.', $token);
            $payload = json_decode(
                base64_decode(str_pad($parts[1], strlen($parts[1]) + (4 - strlen($parts[1]) % 4) % 4, '=')),
                true
            );
            $pangkalanId = $payload['sub']  ?? null;   // e6d9775d-eb4a-...
            $expireAt    = isset($payload['exp']) ? Carbon::createFromTimestamp($payload['exp']) : null;
            $issuedAt    = isset($payload['iat']) ? Carbon::createFromTimestamp($payload['iat']) : null;
        } catch (\Exception $e) {
            // token bukan JWT valid, lanjut tanpa decode
        }

        if (! $pangkalanId) {
            return back()->withErrors(['token' => 'Token tidak valid atau bukan format JWT.']);
        }

        PangkalanToken::updateOrCreate(
            ['pangkalan_id' => $pangkalanId],
            [
                'label'            => $request->label ?: $pangkalanId,
                'token'            => $token,
                'token_issued_at'  => $issuedAt ?? now(),
                'token_expires_at' => $expireAt,
                'is_active'        => true,
            ]
        );

        $msg = "Token disimpan untuk pangkalan: {$pangkalanId}";
        if ($expireAt) {
            $msg .= ". Berlaku hingga: {$expireAt->format('d/m/Y H:i')}";
            if ($expireAt->isPast()) {
                $msg .= " ⚠ Token sudah expired! Harap ambil token baru.";
            }
        }

        return back()->with('success', $msg);
    }

    // ── Trigger scraping manual ───────────────────────────────────

    public function triggerScrape(Request $request)
    {
        $request->validate([
            'from' => 'required|date',
            'to'   => 'required|date|after_or_equal:from',
        ]);

        // Ambil pangkalan_id dari token aktif secara otomatis
        $tokenRecord = PangkalanToken::where('is_active', true)->latest()->first();

        if (! $tokenRecord) {
            return back()->withErrors(['token' => 'Belum ada token aktif. Simpan token terlebih dahulu.']);
        }

        ScrapeTransactionsJob::dispatch(
            $request->from,
            $request->to,
            $tokenRecord->pangkalan_id
        );

        return back()->with('success',
            "Scraping dijadwalkan: {$request->from} s/d {$request->to} " .
            "(pangkalan: {$tokenRecord->label})"
        );
    }

    // ── Ekspor CSV ────────────────────────────────────────────────

    public function exportCsv(Request $request)
    {
        $from = $request->get('from', now()->startOfMonth()->toDateString());
        $to   = $request->get('to',   now()->toDateString());

        $txns = Transaction::dateRange($from, $to)->orderBy('transaction_date')->get();

        $headers = [
            'Content-Type'        => 'text/csv; charset=UTF-8',
            'Content-Disposition' => "attachment; filename=transaksi_{$from}_{$to}.csv",
        ];

        $callback = function () use ($txns) {
            $out = fopen('php://output', 'w');
            fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF)); // BOM UTF-8
            fputcsv($out, ['NIK (sensor)', 'Nama', 'Kategori', 'Tabung', 'Tanggal', 'Waktu', 'ID Transaksi (customerReportId)']);
            foreach ($txns as $t) {
                fputcsv($out, [
                    $t->nationality_id,
                    $t->name,
                    $t->category,
                    $t->total,
                    $t->transaction_date->format('Y-m-d'),
                    Carbon::parse($t->transaction_at)->format('H:i:s'),
                    $t->customer_report_id,
                ]);
            }
            fclose($out);
        };

        return response()->stream($callback, 200, $headers);
    }
}
