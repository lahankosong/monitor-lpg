<?php

namespace App\Http\Controllers;

use App\Models\PangkalanToken;
use App\Models\ScrapeLog;
use App\Jobs\ScrapeTransactionsJob;
use Carbon\Carbon;
use Illuminate\Http\Request;

class TokenCaptureController extends Controller
{
    /**
     * Endpoint yang dipanggil Chrome Extension secara otomatis.
     * Menerima token, simpan, langsung trigger scrape hari ini.
     */
    public function capture(Request $request)
    {
        $data = $request->json()->all();

        $token       = trim(str_replace('Bearer ', '', $data['token'] ?? ''));
        $pangkalanId = $data['pangkalan_id'] ?? null;
        $expAt       = $data['expires_at']   ?? null;
        $issuedAt    = $data['issued_at']    ?? null;

        if (! $token || ! $pangkalanId) {
            return response()->json(['success' => false, 'message' => 'Token atau pangkalan_id kosong'], 400);
        }

        // Cek apakah token sudah expired
        $expiredAt = $expAt ? Carbon::parse($expAt) : null;
        if ($expiredAt && $expiredAt->isPast()) {
            return response()->json(['success' => false, 'message' => 'Token sudah expired'], 400);
        }

        // Simpan / update token
        $record = PangkalanToken::updateOrCreate(
            ['pangkalan_id' => $pangkalanId],
            [
                'token'            => $token,
                'token_issued_at'  => $issuedAt ? Carbon::parse($issuedAt) : now(),
                'token_expires_at' => $expiredAt,
                'is_active'        => true,
            ]
        );

        // Label dari nama yang sudah tersimpan sebelumnya (jika ada)
        $label = $record->label ?: $pangkalanId;

        // Langsung scrape hari ini secara sinkron (tidak lewat queue)
        // karena token hanya valid 15 menit
        $today = now()->toDateString();
        try {
            $job = new ScrapeTransactionsJob($today, $today, $pangkalanId);
            $job->handle();
            $scraped = true;
        } catch (\Exception $e) {
            $scraped = false;
            \Illuminate\Support\Facades\Log::error('[TokenCapture] Scrape gagal: ' . $e->getMessage());
        }

        return response()->json([
            'success'  => true,
            'label'    => $label,
            'pangkalan_id' => $pangkalanId,
            'scraped'  => $scraped,
            'message'  => $scraped
                ? "Token tersimpan & data hari ini berhasil diambil"
                : "Token tersimpan, scrape gagal — cek log",
        ]);
    }

    /**
     * Halaman daftar semua pangkalan + status token masing-masing.
     * Digunakan untuk monitoring 47 pangkalan sekaligus.
     */
    public function pangkalanList()
    {
        $pangkalans = PangkalanToken::orderBy('label')->get()->map(function ($p) {
            $lastLog = ScrapeLog::where('pangkalan_id', $p->pangkalan_id)
                ->latest('scraped_at')->first();

            return [
                'id'          => $p->pangkalan_id,
                'label'       => $p->label ?: $p->pangkalan_id,
                'is_active'   => $p->is_active,
                'token_ok'    => $p->token_expires_at && $p->token_expires_at->isFuture(),
                'expires_at'  => $p->token_expires_at?->format('H:i d/m'),
                'last_scrape' => $lastLog?->scraped_at?->format('d/m H:i'),
                'last_status' => $lastLog?->status,
                'last_saved'  => $lastLog?->records_saved ?? 0,
            ];
        });

        $tokenOk    = $pangkalans->where('token_ok', true)->count();
        $totalSaved = ScrapeLog::where('status', 'success')
            ->whereDate('created_at', today())->sum('records_saved');

        return view('dashboard.pangkalan', compact('pangkalans', 'tokenOk', 'totalSaved'));
    }

    /**
     * Update label nama pangkalan.
     */
    public function updateLabel(Request $request, string $pangkalanId)
    {
        $request->validate(['label' => 'required|string|max:100']);

        PangkalanToken::where('pangkalan_id', $pangkalanId)
            ->update(['label' => $request->label]);

        return back()->with('success', 'Nama pangkalan diperbarui');
    }

    /**
     * Scrape ulang semua pangkalan yang tokennya masih valid.
     */
    public function scrapeAll(Request $request)
    {
        $request->validate([
            'from' => 'required|date',
            'to'   => 'required|date|after_or_equal:from',
        ]);

        $aktif = PangkalanToken::where('is_active', true)
            ->where(function ($q) {
                $q->whereNull('token_expires_at')
                  ->orWhere('token_expires_at', '>', now());
            })->get();

        if ($aktif->isEmpty()) {
            return back()->withErrors(['msg' => 'Tidak ada token aktif. Login ke pangkalan via browser terlebih dahulu.']);
        }

        $count = 0;
        foreach ($aktif as $p) {
            try {
                $job = new ScrapeTransactionsJob($request->from, $request->to, $p->pangkalan_id);
                $job->handle();
                $count++;
            } catch (\Exception $e) {
                \Illuminate\Support\Facades\Log::error("[ScrapeAll] Pangkalan {$p->pangkalan_id}: " . $e->getMessage());
            }
        }

        return back()->with('success', "Scrape selesai: {$count} dari {$aktif->count()} pangkalan berhasil.");
    }
}
