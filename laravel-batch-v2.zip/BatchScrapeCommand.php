<?php

namespace App\Console\Commands;

use App\Http\Controllers\BatchScrapeController;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class BatchScrapeCommand extends Command
{
    protected $signature   = 'batch:scrape {--from= : Tanggal mulai} {--to= : Tanggal akhir}';
    protected $description = 'Jalankan batch scraping semua pangkalan via Playwright (background)';

    public function handle(): int
    {
        $from = $this->option('from') ?? now()->startOfWeek()->toDateString();
        $to   = $this->option('to')   ?? now()->toDateString();

        $this->info("[BatchScrape] Mulai: {$from} s/d {$to}");
        Log::info("[BatchScrape] Artisan command dimulai: {$from} s/d {$to}");

        $pythonPath  = env('PYTHON_PATH', 'python');
        $scriptPath  = base_path('scripts/auto_login_batch.py');
        $accountPath = base_path('scripts/accounts.json');
        $resultFile  = storage_path('app/batch_result.json');
        $logFile     = storage_path('logs/batch_scrape.log');

        if (! file_exists($scriptPath)) {
            $this->error("Script tidak ditemukan: {$scriptPath}");
            Cache::forget('batch_scrape_running');
            return 1;
        }

        // Set timeout PHP tidak berlaku untuk exec() — aman untuk proses panjang
        set_time_limit(0);

        $cmd = sprintf(
            '%s %s --accounts %s --from %s --to %s',
            escapeshellcmd($pythonPath),
            escapeshellarg($scriptPath),
            escapeshellarg($accountPath),
            escapeshellarg($from),
            escapeshellarg($to),
        );

        $this->info("Menjalankan Playwright login batch...");
        $this->info("(Proses ini membutuhkan beberapa menit untuk 47 pangkalan)");

        // Jalankan Python — output ke file
        $output   = [];
        $exitCode = 0;
        exec($cmd . " 2>>" . escapeshellarg($logFile), $output, $exitCode);

        $outputStr = implode("\n", $output);

        // Simpan output mentah ke file untuk debugging
        file_put_contents($logFile, $outputStr . "\n", FILE_APPEND);

        // Parse JSON dari output
        $jsonStart = strrpos($outputStr, '{');
        if ($jsonStart === false) {
            $this->error("Output Python tidak valid. Cek: {$logFile}");
            Cache::forget('batch_scrape_running');
            return 1;
        }

        $batchResult = json_decode(substr($outputStr, $jsonStart), true);
        if (! $batchResult) {
            $this->error("JSON tidak valid. Cek: {$logFile}");
            Cache::forget('batch_scrape_running');
            return 1;
        }

        // Tambahkan info tanggal ke tiap result untuk keperluan logging
        foreach ($batchResult['results'] as &$result) {
            $result['from'] = $from;
            $result['to']   = $to;
        }

        // Simpan result ke file untuk di-import
        file_put_contents($resultFile, json_encode($batchResult, JSON_PRETTY_PRINT));

        $this->info("Login batch selesai. Mengimport data ke database...");

        // Import ke database
        $controller = app(BatchScrapeController::class);
        $stats = $controller->importResult($resultFile);

        $this->info("✓ Berhasil: {$stats['berhasil']} pangkalan");
        $this->info("✗ Gagal   : {$stats['gagal']} pangkalan");
        $this->info("+ Transaksi baru: {$stats['total_baru']}");

        Log::info("[BatchScrape] Selesai", $stats);

        return 0;
    }
}
