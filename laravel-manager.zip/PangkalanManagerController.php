<?php

namespace App\Http\Controllers;

use App\Models\PangkalanSession;
use App\Models\PangkalanToken;
use App\Models\ScrapeLog;
use App\Jobs\ScrapeTransactionsJob;
use App\Services\AutoLoginService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;

class PangkalanManagerController extends Controller
{
    public function __construct(private AutoLoginService $autoLogin) {}

    /**
     * Halaman utama daftar 47 pangkalan — one-click scrape.
     */
    public function index()
    {
        $pangkalans = PangkalanSession::where('is_active', true)
            ->orderBy('label')
            ->get()
            ->map(function ($p) {
                $token   = PangkalanToken::where('pangkalan_id', $p->pangkalan_id)->first();
                $lastLog = ScrapeLog::where('pangkalan_id', $p->pangkalan_id)
                    ->latest('scraped_at')->first();

                return [
                    'id'             => $p->pangkalan_id,
                    'label'          => $p->label ?: 'Pangkalan '.substr($p->pangkalan_id, 0, 6),
                    'username'       => $p->username,
                    'has_password'   => ! empty($p->password_encrypted),
                    'token_valid'    => $token?->token_expires_at?->isFuture() ?? false,
                    'token_expires'  => $token?->token_expires_at?->format('H:i'),
                    'cookies_fresh'  => $p->isCookiesFresh(),
                    'cookies_age'    => $p->cookies_captured_at?->diffForHumans() ?? 'Belum ada',
                    'needs_relogin'  => ! $p->isCookiesFresh() && ! ($token?->token_expires_at?->isFuture() ?? false),
                    'last_scrape'    => $lastLog?->scraped_at?->format('d/m H:i'),
                    'last_status'    => $lastLog?->status,
                    'last_saved'     => $lastLog?->records_saved ?? 0,
                ];
            });

        $needsRelogin = $pangkalans->where('needs_relogin', true)->count();
        $tokenValid   = $pangkalans->where('token_valid', true)->count();
        $cookiesFresh = $pangkalans->where('cookies_fresh', true)->count();

        return view('dashboard.pangkalan-manager', compact(
            'pangkalans', 'needsRelogin', 'tokenValid', 'cookiesFresh'
        ));
    }

    /**
     * Tambah pangkalan baru — simpan credentials + cookies sekaligus.
     */
    public function store(Request $request)
    {
        $request->validate([
            'label'    => 'required|string|max:100',
            'username' => 'required|string|max:100',
            'password' => 'required|string',
            'token'    => 'required|string',   // token dari login pertama (manual)
            'cookies'  => 'nullable|string',   // cookies JSON (opsional)
        ]);

        // Decode token untuk ambil pangkalan_id
        $token = trim(str_replace('Bearer ', '', $request->token));
        try {
            $parts   = explode('.', $token);
            $payload = json_decode(base64_decode(
                str_pad(strtr($parts[1], '-_', '+/'),
                strlen($parts[1]) + (4 - strlen($parts[1]) % 4) % 4, '=')
            ), true);
            $pangkalanId = $payload['sub'] ?? null;
            $expiredAt   = isset($payload['exp']) ? Carbon::createFromTimestamp($payload['exp']) : null;
        } catch (\Exception $e) {
            return back()->withErrors(['token' => 'Token tidak valid.']);
        }

        if (! $pangkalanId) {
            return back()->withErrors(['token' => 'ID Pangkalan tidak ditemukan dalam token.']);
        }

        // Simpan session pangkalan
        $session = PangkalanSession::updateOrCreate(
            ['pangkalan_id' => $pangkalanId],
            [
                'label'              => $request->label,
                'username'           => $request->username,
                'password_encrypted' => Crypt::encryptString($request->password),
                'is_active'          => true,
                'last_login_at'      => now(),
            ]
        );

        // Simpan cookies jika ada
        if ($request->cookies) {
            try {
                $cookiesArr = json_decode($request->cookies, true);
                if (is_array($cookiesArr)) {
                    $session->setCookiesData($cookiesArr);
                }
            } catch (\Exception $e) {}
        }

        // Simpan token
        $this->autoLogin->saveToken($pangkalanId, $token);

        // Update label di PangkalanToken juga
        PangkalanToken::where('pangkalan_id', $pangkalanId)
            ->update(['label' => $request->label]);

        return back()->with('success', "Pangkalan '{$request->label}' berhasil ditambahkan.");
    }

    /**
     * One-click scrape satu pangkalan.
     * Otomatis coba pakai token → cookies → minta login ulang.
     */
    public function scrapeOne(Request $request, string $pangkalanId)
    {
        $request->validate([
            'from' => 'required|date',
            'to'   => 'required|date|after_or_equal:from',
        ]);

        $session = PangkalanSession::where('pangkalan_id', $pangkalanId)->first();
        $label   = $session?->label ?? $pangkalanId;

        // Coba ambil token otomatis
        $token = $this->autoLogin->getActiveToken($pangkalanId);

        if (! $token) {
            // Tidak bisa auto — arahkan ke halaman input token manual
            return redirect()->route('dashboard.token.input')
                ->with('warning', "Token untuk '{$label}' sudah expired dan cookies tidak bisa dipakai. Silakan login ulang.");
        }

        // Pastikan token tersimpan
        $tokenRecord = PangkalanToken::where('pangkalan_id', $pangkalanId)->first();
        if ($tokenRecord) {
            $tokenRecord->update(['token' => $token, 'is_active' => true]);
        }

        // Scrape
        try {
            $job = new ScrapeTransactionsJob($request->from, $request->to, $pangkalanId);
            $job->handle();

            $lastLog = ScrapeLog::where('pangkalan_id', $pangkalanId)
                ->latest('scraped_at')->first();

            return back()->with('success',
                "✓ {$label}: {$lastLog?->records_saved} transaksi tersimpan ({$request->from} s/d {$request->to})"
            );
        } catch (\Exception $e) {
            return back()->withErrors(['msg' => "Scrape gagal untuk {$label}: " . $e->getMessage()]);
        }
    }

    /**
     * Scrape semua pangkalan yang bisa (token/cookies masih valid).
     */
    public function scrapeAll(Request $request)
    {
        $request->validate([
            'from' => 'required|date',
            'to'   => 'required|date|after_or_equal:from',
        ]);

        $sessions  = PangkalanSession::where('is_active', true)->get();
        $berhasil  = 0;
        $gagal     = 0;
        $needLogin = 0;

        foreach ($sessions as $session) {
            $token = $this->autoLogin->getActiveToken($session->pangkalan_id);

            if (! $token) {
                $needLogin++;
                continue;
            }

            try {
                $job = new ScrapeTransactionsJob($request->from, $request->to, $session->pangkalan_id);
                $job->handle();
                $berhasil++;
            } catch (\Exception $e) {
                $gagal++;
                \Illuminate\Support\Facades\Log::error("[ScrapeAll] {$session->pangkalan_id}: " . $e->getMessage());
            }
        }

        $msg = "Scrape selesai: {$berhasil} berhasil";
        if ($gagal)     $msg .= ", {$gagal} error";
        if ($needLogin) $msg .= ", {$needLogin} perlu login ulang";

        return back()->with('success', $msg);
    }

    /**
     * Simpan cookies dari browser untuk satu pangkalan.
     * Dipanggil via AJAX dari halaman setup.
     */
    public function saveCookies(Request $request, string $pangkalanId)
    {
        $session = PangkalanSession::where('pangkalan_id', $pangkalanId)->firstOrFail();

        $cookies = $request->input('cookies');
        if (is_string($cookies)) $cookies = json_decode($cookies, true);

        if (! is_array($cookies) || empty($cookies)) {
            return response()->json(['success' => false, 'message' => 'Cookies tidak valid']);
        }

        $session->setCookiesData($cookies);
        $session->update(['last_login_at' => now()]);

        return response()->json([
            'success' => true,
            'message' => "Cookies disimpan untuk {$session->label}",
            'count'   => count($cookies),
        ]);
    }

    /**
     * Hapus pangkalan.
     */
    public function destroy(string $pangkalanId)
    {
        PangkalanSession::where('pangkalan_id', $pangkalanId)->delete();
        PangkalanToken::where('pangkalan_id', $pangkalanId)->delete();
        return back()->with('success', 'Pangkalan dihapus.');
    }
}
