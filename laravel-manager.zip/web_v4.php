<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\TokenCaptureController;
use App\Http\Controllers\TokenInputController;
use App\Http\Controllers\PangkalanManagerController;
use Illuminate\Support\Facades\Route;

Route::prefix('dashboard')->name('dashboard.')->group(function () {

    Route::get('/',           [DashboardController::class, 'index'])->name('index');
    Route::get('/nik',        [DashboardController::class, 'nikList'])->name('nik.list');
    Route::get('/nik/detail', [DashboardController::class, 'nikDetail'])->name('nik.detail');
    Route::get('/export/csv', [DashboardController::class, 'exportCsv'])->name('export.csv');
    Route::post('/scrape',    [DashboardController::class, 'triggerScrape'])->name('scrape');

    // Input token manual
    Route::get('/token/input',     [TokenInputController::class, 'index'])->name('token.input');
    Route::post('/token/input',    [TokenInputController::class, 'store'])->name('token.input.store');
    Route::post('/token/rescrape', [TokenInputController::class, 'rescrape'])->name('token.rescrape');

    // Manager pangkalan — one-click scrape
    Route::get('/pangkalan',                          [PangkalanManagerController::class, 'index'])->name('pangkalan.list');
    Route::post('/pangkalan',                         [PangkalanManagerController::class, 'store'])->name('pangkalan.store');
    Route::post('/pangkalan/scrape-all',              [PangkalanManagerController::class, 'scrapeAll'])->name('pangkalan.scrape-all');
    Route::post('/pangkalan/{id}/scrape',             [PangkalanManagerController::class, 'scrapeOne'])->name('pangkalan.scrape-one');
    Route::post('/pangkalan/{id}/cookies',            [PangkalanManagerController::class, 'saveCookies'])->name('pangkalan.cookies');
    Route::delete('/pangkalan/{id}',                  [PangkalanManagerController::class, 'destroy'])->name('pangkalan.destroy');

    // Lama — tetap ada untuk kompatibilitas
    Route::post('/token',                             [DashboardController::class, 'saveToken'])->name('token.save');
    Route::get('/pangkalan-lama',                     [TokenCaptureController::class, 'pangkalanList'])->name('pangkalan.old');
    Route::post('/pangkalan-lama/{id}/label',         [TokenCaptureController::class, 'updateLabel'])->name('pangkalan.label');
});

Route::match(['OPTIONS','POST'], '/dashboard/token/capture', [TokenCaptureController::class, 'capture'])
    ->name('token.capture')
    ->withoutMiddleware([\Illuminate\Foundation\Http\Middleware\VerifyCsrfToken::class]);

Route::get('/', fn() => redirect()->route('dashboard.index'));
