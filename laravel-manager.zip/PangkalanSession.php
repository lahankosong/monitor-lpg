<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Crypt;

class PangkalanSession extends Model
{
    protected $fillable = [
        'pangkalan_id', 'label', 'username',
        'password_encrypted', 'cookies',
        'cookies_captured_at', 'last_login_at', 'is_active',
    ];

    protected $casts = [
        'cookies_captured_at' => 'datetime',
        'last_login_at'       => 'datetime',
        'is_active'           => 'boolean',
    ];

    // Simpan password terenkripsi
    public function setPasswordAttribute(string $password): void
    {
        $this->attributes['password_encrypted'] = Crypt::encryptString($password);
    }

    // Ambil password terdekripsi
    public function getPasswordAttribute(): ?string
    {
        if (! $this->password_encrypted) return null;
        try {
            return Crypt::decryptString($this->password_encrypted);
        } catch (\Exception $e) {
            return null;
        }
    }

    // Simpan cookies sebagai JSON
    public function setCookiesData(array $cookies): void
    {
        $this->cookies              = json_encode($cookies);
        $this->cookies_captured_at  = now();
        $this->save();
    }

    // Ambil cookies sebagai array
    public function getCookiesData(): array
    {
        return $this->cookies ? json_decode($this->cookies, true) : [];
    }

    // Cek apakah cookies masih kemungkinan valid (< 24 jam)
    public function isCookiesFresh(): bool
    {
        if (! $this->cookies_captured_at) return false;
        return $this->cookies_captured_at->diffInHours(now()) < 24;
    }

    public function token(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(PangkalanToken::class, 'pangkalan_id', 'pangkalan_id');
    }
}
