@extends('layouts.app')
@section('title', 'Manager Pangkalan')

@section('content')

{{-- Header --}}
<div class="flex items-center justify-between mb-5 flex-wrap gap-3">
  <div>
    <h1 class="text-lg font-semibold">Manager 47 Pangkalan</h1>
    <p class="text-xs text-gray-500 mt-0.5">
      Klik <strong>Scrape</strong> pada pangkalan mana saja — sistem otomatis pakai token/cookies tersimpan.
    </p>
  </div>
  <div class="flex gap-2 flex-wrap">
    <button onclick="document.getElementById('modal-tambah').classList.remove('hidden')"
            class="text-sm border border-gray-300 rounded-lg px-4 py-2 hover:bg-gray-50">
      + Tambah Pangkalan
    </button>
    <button onclick="document.getElementById('modal-scrape-all').classList.remove('hidden')"
            class="text-sm bg-blue-600 text-white rounded-lg px-4 py-2 hover:bg-blue-700">
      Scrape Semua ({{ $cookiesFresh + $tokenValid }} siap)
    </button>
  </div>
</div>

{{-- Status bar --}}
<div class="grid grid-cols-3 gap-3 mb-5">
  <div class="bg-green-50 border border-green-200 rounded-xl p-3 text-center">
    <p class="text-2xl font-semibold text-green-700">{{ $tokenValid }}</p>
    <p class="text-xs text-green-600">Token aktif</p>
  </div>
  <div class="bg-blue-50 border border-blue-200 rounded-xl p-3 text-center">
    <p class="text-2xl font-semibold text-blue-700">{{ $cookiesFresh }}</p>
    <p class="text-xs text-blue-600">Cookies segar (&lt;24 jam)</p>
  </div>
  <div class="bg-amber-50 border border-amber-200 rounded-xl p-3 text-center">
    <p class="text-2xl font-semibold text-amber-700">{{ $needsRelogin }}</p>
    <p class="text-xs text-amber-600">Perlu login ulang</p>
  </div>
</div>

@if(session('success'))
<div class="bg-green-50 border border-green-200 rounded-xl p-3 mb-4 text-sm text-green-800">✓ {{ session('success') }}</div>
@endif
@if(session('warning'))
<div class="bg-amber-50 border border-amber-200 rounded-xl p-3 mb-4 text-sm text-amber-800">⚠ {{ session('warning') }}</div>
@endif

{{-- Tabel pangkalan --}}
<div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500 uppercase tracking-wide">
      <tr>
        <th class="text-left px-4 py-3">Pangkalan</th>
        <th class="text-left px-4 py-3">Username</th>
        <th class="text-center px-4 py-3">Status</th>
        <th class="text-right px-4 py-3">Cookies</th>
        <th class="text-right px-4 py-3">Scrape Terakhir</th>
        <th class="text-right px-4 py-3">Txn</th>
        <th class="px-4 py-3 text-right">Aksi</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-gray-100">
      @forelse($pangkalans as $p)
      <tr class="{{ $p['needs_relogin'] ? 'bg-amber-50/50' : 'hover:bg-gray-50' }}">
        <td class="px-4 py-3 font-medium">{{ $p['label'] }}</td>
        <td class="px-4 py-3 text-xs text-gray-500">{{ $p['username'] }}</td>
        <td class="px-4 py-3 text-center">
          @if($p['token_valid'])
            <span class="badge-aman">Token aktif s/d {{ $p['token_expires'] }}</span>
          @elseif($p['cookies_fresh'])
            <span class="badge-new">Cookies segar</span>
          @else
            <span class="badge-warn">Perlu login ulang</span>
          @endif
        </td>
        <td class="px-4 py-3 text-right text-xs text-gray-400">
          {{ $p['cookies_age'] }}
        </td>
        <td class="px-4 py-3 text-right text-xs text-gray-500">
          @if($p['last_scrape'])
            {{ $p['last_scrape'] }}
            <span class="{{ $p['last_status']==='success' ? 'text-green-600':'text-red-500' }}">
              ({{ $p['last_status'] }})
            </span>
          @else
            <span class="text-gray-300">Belum pernah</span>
          @endif
        </td>
        <td class="px-4 py-3 text-right text-xs font-medium">{{ $p['last_saved'] ?: '—' }}</td>
        <td class="px-4 py-3 text-right">
          <div class="flex items-center justify-end gap-2">
            @if($p['needs_relogin'])
              {{-- Perlu login ulang dulu --}}
              <a href="{{ route('dashboard.token.input') }}"
                 class="text-xs text-amber-600 hover:underline">Login ulang</a>
            @else
              {{-- Tombol scrape langsung --}}
              <form action="{{ route('dashboard.pangkalan.scrape-one', $p['id']) }}" method="POST"
                    class="inline scrape-form">
                @csrf
                <input type="hidden" name="from" class="input-from">
                <input type="hidden" name="to"   class="input-to">
                <button type="submit"
                        class="text-xs bg-blue-600 text-white rounded px-3 py-1 hover:bg-blue-700">
                  Scrape
                </button>
              </form>
            @endif
            <a href="{{ route('dashboard.nik.list', ['from' => now()->startOfWeek()->toDateString(), 'to' => now()->toDateString()]) }}"
               class="text-xs text-gray-400 hover:text-gray-700">NIK</a>
          </div>
        </td>
      </tr>
      @empty
      <tr>
        <td colspan="7" class="px-4 py-10 text-center text-gray-400">
          Belum ada pangkalan. Klik "+ Tambah Pangkalan" untuk mulai.
        </td>
      </tr>
      @endforelse
    </tbody>
  </table>
</div>

{{-- Modal: Tambah Pangkalan --}}
<div id="modal-tambah" class="hidden fixed inset-0 bg-black/40 flex items-center justify-center z-50">
  <div class="bg-white rounded-xl shadow-lg p-6 w-full max-w-lg max-h-screen overflow-y-auto">
    <h2 class="font-semibold text-base mb-1">Tambah Pangkalan Baru</h2>
    <p class="text-xs text-gray-400 mb-4">
      Lakukan sekali saja per pangkalan. Credentials dan cookies disimpan untuk login otomatis berikutnya.
    </p>

    <div class="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4 text-xs text-blue-700">
      <strong>Langkah setup:</strong><br>
      1. Login ke MyPertamina pangkalan ini<br>
      2. Buka Laporan Penjualan → F12 → Network → filter <code>api-map</code> → copy nilai Authorization<br>
      3. Isi form ini lengkap → Simpan
    </div>

    <form action="{{ route('dashboard.pangkalan.store') }}" method="POST">
      @csrf
      <div class="space-y-3">
        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-xs text-gray-500 mb-1">Nama Pangkalan *</label>
            <input name="label" required placeholder="mis: Pangkalan Bu Sari"
                   class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500">
          </div>
          <div>
            <label class="block text-xs text-gray-500 mb-1">Username (HP/Email) *</label>
            <input name="username" required placeholder="08xxxxxxxxxx"
                   class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500">
          </div>
        </div>
        <div>
          <label class="block text-xs text-gray-500 mb-1">Password *</label>
          <input type="password" name="password" required
                 class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500">
          <p class="text-xs text-gray-400 mt-1">Disimpan terenkripsi — tidak bisa dibaca balik</p>
        </div>
        <div>
          <label class="block text-xs text-gray-500 mb-1">Bearer Token (dari DevTools) *</label>
          <textarea name="token" rows="3" required
                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-xs font-mono focus:outline-none focus:border-blue-500"
                    placeholder="eyJhbGci..."></textarea>
        </div>
      </div>
      <div class="flex gap-2 mt-4">
        <button type="submit" class="bg-blue-600 text-white rounded-lg px-4 py-2 text-sm hover:bg-blue-700">
          Simpan Pangkalan
        </button>
        <button type="button" onclick="document.getElementById('modal-tambah').classList.add('hidden')"
                class="border border-gray-300 rounded-lg px-4 py-2 text-sm hover:bg-gray-50">Batal</button>
      </div>
    </form>
  </div>
</div>

{{-- Modal: Scrape Semua --}}
<div id="modal-scrape-all" class="hidden fixed inset-0 bg-black/40 flex items-center justify-center z-50">
  <div class="bg-white rounded-xl shadow-lg p-6 w-full max-w-sm">
    <h2 class="font-semibold text-base mb-1">Scrape Semua Pangkalan</h2>
    <p class="text-xs text-gray-400 mb-4">
      Sistem otomatis pakai token/cookies yang tersimpan.
      Pangkalan yang perlu login ulang akan dilewati.
    </p>
    <form action="{{ route('dashboard.pangkalan.scrape-all') }}" method="POST">
      @csrf
      <div class="grid grid-cols-2 gap-2">
        <div>
          <label class="block text-xs text-gray-500 mb-1">Dari</label>
          <input type="date" name="from" id="from-all" value="{{ now()->startOfWeek()->toDateString() }}"
                 class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm" required>
        </div>
        <div>
          <label class="block text-xs text-gray-500 mb-1">Sampai</label>
          <input type="date" name="to" id="to-all" value="{{ now()->toDateString() }}"
                 class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm" required>
        </div>
      </div>
      <div class="flex gap-2 mt-4">
        <button type="submit" class="bg-blue-600 text-white rounded-lg px-4 py-2 text-sm hover:bg-blue-700">
          Jalankan
        </button>
        <button type="button" onclick="document.getElementById('modal-scrape-all').classList.add('hidden')"
                class="border border-gray-300 rounded-lg px-4 py-2 text-sm hover:bg-gray-50">Batal</button>
      </div>
    </form>
  </div>
</div>

@endsection

@push('scripts')
<script>
// Set tanggal dari/sampai ke semua form scrape individual
const fromAll = '{{ now()->startOfWeek()->toDateString() }}';
const toAll   = '{{ now()->toDateString() }}';

document.querySelectorAll('.scrape-form').forEach(form => {
  form.querySelector('.input-from').value = fromAll;
  form.querySelector('.input-to').value   = toAll;
});

// Sync tanggal dari modal scrape-all ke form individual
document.getElementById('from-all').addEventListener('change', function() {
  document.querySelectorAll('.input-from').forEach(el => el.value = this.value);
});
document.getElementById('to-all').addEventListener('change', function() {
  document.querySelectorAll('.input-to').forEach(el => el.value = this.value);
});
</script>
@endpush
