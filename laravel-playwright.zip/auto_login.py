"""
auto_login.py — Playwright auto-login MyPertamina
Dipanggil dari Laravel via subprocess:
  python auto_login.py --email xxx --pin xxx --pangkalan_id xxx

Output JSON ke stdout, dibaca oleh Laravel.
"""

import asyncio
import aiohttp
import argparse
import json
import sys
from playwright.async_api import async_playwright


async def get_token_and_info(email: str, pin: str) -> dict:
    """
    Login ke MyPertamina menggunakan Playwright (browser sungguhan).
    Tangkap Bearer token dari request, lalu ambil info stok/pangkalan.
    """
    result = {
        "success":       False,
        "token":         None,
        "pangkalan_id":  None,   # dari JWT sub
        "registration_id": None, # dari API products/user
        "store_name":    None,
        "stock_available": None,
        "error":         None,
    }

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=True,
            args=[
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-blink-features=AutomationControlled",
            ]
        )
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15",
            viewport={"width": 390, "height": 844},
        )
        page = await context.new_page()

        token_holder = {"token": None}

        # Intersep semua request — ambil Bearer token
        def handle_request(request):
            auth = request.headers.get("authorization", "")
            if auth.startswith("Bearer ") and not token_holder["token"]:
                token_holder["token"] = auth.replace("Bearer ", "").strip()

        page.on("request", handle_request)

        try:
            await page.goto(
                "https://subsiditepatlpg.mypertamina.id/merchant-login",
                wait_until="networkidle",
                timeout=30000
            )

            # Isi email/username
            await page.locator("input").nth(0).fill(email)
            await asyncio.sleep(0.5)

            # Isi PIN/password
            await page.locator("input").nth(1).fill(pin)
            await asyncio.sleep(0.5)

            # Klik tombol MASUK
            await page.locator("button").filter(has_text="MASUK").click()

            # Tunggu token muncul (max 30 detik)
            for _ in range(30):
                if token_holder["token"]:
                    break
                await asyncio.sleep(1)

            if not token_holder["token"]:
                result["error"] = "Token tidak tertangkap setelah login — mungkin reCAPTCHA aktif atau kredensial salah"
                return result

            token = token_holder["token"]
            result["token"] = token

            # Decode JWT untuk ambil pangkalan_id (sub)
            try:
                import base64
                parts   = token.split(".")
                payload = json.loads(base64.b64decode(
                    parts[1] + "=" * (4 - len(parts[1]) % 4)
                ))
                result["pangkalan_id"] = payload.get("sub")
            except Exception:
                pass

        except Exception as e:
            result["error"] = f"Error browser: {str(e)}"
            return result
        finally:
            await browser.close()

    # Ambil info pangkalan dari API
    if result["token"]:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    "https://api-map.my-pertamina.id/general/products/v1/products/user",
                    headers={
                        "Authorization": f"Bearer {result['token']}",
                        "Accept":        "application/json",
                        "User-Agent":    "Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15",
                        "Origin":        "https://subsiditepatlpg.mypertamina.id",
                    },
                    timeout=aiohttp.ClientTimeout(total=10)
                ) as res:
                    if res.status == 200:
                        data = await res.json()
                        if data.get("success") and data.get("data"):
                            d = data["data"]
                            result["registration_id"]  = d.get("registrationId")
                            result["store_name"]       = d.get("storeName")
                            result["stock_available"]  = d.get("stockAvailable")
                            result["stock_redeem"]     = d.get("stockRedeem")
                            result["sold"]             = d.get("sold")
                            result["success"]          = True
        except Exception as e:
            # Token berhasil tapi info stok gagal — tetap return token
            result["success"] = result["token"] is not None
            result["error"]   = f"Token OK tapi gagal ambil info stok: {str(e)}"

    return result


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--email",        required=True)
    parser.add_argument("--pin",          required=True)
    parser.add_argument("--pangkalan_id", required=False, default=None)
    args = parser.parse_args()

    result = await get_token_and_info(args.email, args.pin)

    # Output JSON ke stdout — dibaca Laravel
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["success"] else 1)


if __name__ == "__main__":
    asyncio.run(main())
