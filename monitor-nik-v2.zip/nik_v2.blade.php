@extends('layouts.app')
@section('title', 'Monitor NIK')

@section('content')

{{-- Header + Filter ─────────────────────────────────────────────────── --}}
<div class="mb-5">
  <h1 class="text-lg font-semibold mb-3">Monitor NIK per Transaksi</h1>
  <form method="GET" class="bg-white rounded-xl border border-gray-200 p-4">
    <div class="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">

      {{-- Dropdown pangkalan (alfabet) --}}
      <div class="md:col-span-2">
        <label class="block text-xs text-gray-500 mb-1">Pangkalan</label>
        <select name="pangkalan_id"
                class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-blue-500">
          <option value="">— Semua Pangkalan —</option>
          @foreach($pangkalans->sortBy('label') as $p)
          <option value="{{ $p['id'] }}" {{ $pangkalanId === $p['id'] ? 'selected' : '' }}>
            {{ $p['label'] }}
          </option>
          @endforeach
        </select>
      </div>

      {{-- Tipe konsumen --}}
      <div>
        <label class="block text-xs text-gray-500 mb-1">Tipe Konsumen</label>
        <select name="kategori"
                class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
          <option value="">— Semua Tipe —</option>
          <option value="Rumah Tangga"    {{ $filterKat==='Rumah Tangga'    ? 'selected':'' }}>Rumah Tangga</option>
          <option value="Usaha Mikro"     {{ $filterKat==='Usaha Mikro'     ? 'selected':'' }}>Usaha Mikro</option>
          <option value="Pengecer"        {{ $filterKat==='Pengecer'        ? 'selected':'' }}>Pengecer</option>
          <option value="Sub Pangkalan"   {{ $filterKat==='Sub Pangkalan'   ? 'selected':'' }}>Sub Pangkalan</option>
        </select>
      </div>

      {{-- Status --}}
      <div>
        <label class="block text-xs text-gray-500 mb-1">Status</label>
        <select name="status"
                class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
          <option value="">— Semua Status —</option>
          <option value="alert" {{ $filterStatus==='alert' ? 'selected':'' }}>🔴 Pelanggaran</option>
          <option value="warn"  {{ $filterStatus==='warn'  ? 'selected':'' }}>🟡 Perlu Pantau</option>
          <option value="aman"  {{ $filterStatus==='aman'  ? 'selected':'' }}>🟢 Aman</option>
          <option value="new"   {{ $filterStatus==='new'   ? 'selected':'' }}>🔵 Data Baru</option>
        </select>
      </div>
    </div>

    <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
      <div>
        <label class="block text-xs text-gray-500 mb-1">Dari</label>
        <input type="date" name="from" value="{{ $from }}"
               class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
      </div>
      <div>
        <label class="block text-xs text-gray-500 mb-1">Sampai</label>
        <input type="date" name="to" value="{{ $to }}"
               class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
      </div>
      <div>
        <label class="block text-xs text-gray-500 mb-1">Interval Min (hari)</label>
        <select name="interval" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
          <option value="5"  {{ $minInterval==5  ? 'selected':'' }}>5 hari</option>
          <option value="7"  {{ $minInterval==7  ? 'selected':'' }}>7 hari</option>
          <option value="14" {{ $minInterval==14 ? 'selected':'' }}>14 hari</option>
        </select>
      </div>
      <div>
        <label class="block text-xs text-gray-500 mb-1">Cari NIK / Nama</label>
        <input type="text" name="search" value="{{ $search }}" placeholder="NIK atau nama..."
               class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
      </div>
    </div>

    <div class="flex gap-2 mt-3">
      <button type="submit"
              class="bg-gray-800 text-white rounded-lg px-4 py-2 text-sm hover:bg-gray-700">
        Filter
      </button>
      <a href="{{ route('dashboard.nik.list') }}"
         class="border border-gray-300 rounded-lg px-4 py-2 text-sm hover:bg-gray-50">Reset</a>
      <a href="{{ route('dashboard.export.csv', array_filter(['from'=>$from,'to'=>$to,'pangkalan_id'=>$pangkalanId])) }}"
         class="border border-gray-300 rounded-lg px-4 py-2 text-sm hover:bg-gray-50 ml-auto">
        Ekspor CSV
      </a>
    </div>
  </form>
</div>

{{-- Warning pengecer --}}
@if(!empty($pengecerWarnings))
<div class="bg-red-50 border border-red-200 rounded-xl p-4 mb-5">
  <p class="font-medium text-sm text-red-800 mb-2">⚠ Pengecer melebihi 10% total pangkalan</p>
  @foreach($pengecerWarnings as $w)
  <p class="text-xs text-red-700">• {{ $w['pesan'] }}</p>
  @endforeach
</div>
@endif

{{-- Tabel NIK ────────────────────────────────────────────────────────── --}}
<div class="bg-white rounded-xl border border-gray-200 overflow-hidden">
  <table class="w-full text-sm">
    <thead class="bg-gray-50 text-xs text-gray-500 uppercase tracking-wide">
      <tr>
        <th class="text-left px-4 py-3">NIK (sensor)</th>
        <th class="text-left px-4 py-3">Nama</th>
        <th class="text-left px-4 py-3">Tipe</th>
        <th class="text-right px-4 py-3">Txn</th>
        <th class="text-right px-4 py-3">Tabung</th>
        <th class="text-right px-4 py-3">Aset</th>
        <th class="text-right px-4 py-3">Jarak Rata²</th>
        <th class="text-left px-4 py-3">Pelanggaran</th>
        <th class="text-left px-4 py-3">Status</th>
        <th class="px-4 py-3"></th>
      </tr>
    </thead>
    <tbody class="divide-y divide-gray-100">
      @forelse($groups as $n)
      @php
        $hasAlert = collect($n['all_alerts'])->where('level','alert')->isNotEmpty();
        $hasWarn  = collect($n['all_alerts'])->where('level','warn')->isNotEmpty();
        $rowBg    = $hasAlert ? 'bg-red-50/40' : ($hasWarn ? 'bg-amber-50/30' : 'hover:bg-gray-50');
      @endphp
      <tr class="{{ $rowBg }}">
        <td class="px-4 py-3 font-mono text-xs text-gray-500">{{ $n['nik'] }}</td>
        <td class="px-4 py-3 font-medium">
          {{ $n['nama'] }}
          @if($n['store_name'])
            <span class="block text-xs text-gray-400 font-normal">{{ $n['store_name'] }}</span>
          @endif
        </td>
        <td class="px-4 py-3">
          @php
            $kat = $n['kategori'] ?? 'Rumah Tangga';
            $katColor = match(true) {
              str_contains(strtolower($kat),'rumah') => 'bg-blue-100 text-blue-700',
              str_contains(strtolower($kat),'mikro') => 'bg-purple-100 text-purple-700',
              str_contains(strtolower($kat),'pengecer') => 'bg-orange-100 text-orange-700',
              str_contains(strtolower($kat),'sub') => 'bg-orange-100 text-orange-700',
              default => 'bg-gray-100 text-gray-600',
            };
          @endphp
          <span class="text-xs px-2 py-0.5 rounded-full font-medium {{ $katColor }}">
            {{ $kat }}
          </span>
        </td>
        <td class="px-4 py-3 text-right">{{ $n['total_txn'] }}</td>
        <td class="px-4 py-3 text-right font-semibold">{{ $n['total_tabung'] }}</td>
        <td class="px-4 py-3 text-right text-xs">
          <span title="Aset kepemilikan tabung (max sekali beli)">
            {{ $n['max_tabung_sekali'] }} tb
          </span>
        </td>
        <td class="px-4 py-3 text-right text-xs {{ ($n['avg_gap'] !== null && $n['avg_gap'] < $minInterval) ? 'text-red-600 font-semibold' : 'text-gray-500' }}">
          {{ $n['avg_gap'] !== null ? $n['avg_gap'].'h' : '—' }}
        </td>
        <td class="px-4 py-3">
          @if(!empty($n['all_alerts']))
            @foreach(array_slice($n['all_alerts'], 0, 2) as $v)
            <div class="text-xs {{ $v['level']==='alert' ? 'text-red-600' : 'text-amber-600' }} leading-tight">
              {{ $v['level']==='alert' ? '🔴' : '🟡' }} {{ Str::limit($v['pesan'], 45) }}
            </div>
            @endforeach
            @if(count($n['all_alerts']) > 2)
            <div class="text-xs text-gray-400">+{{ count($n['all_alerts'])-2 }} lainnya</div>
            @endif
          @else
            <span class="text-xs text-gray-300">—</span>
          @endif
        </td>
        <td class="px-4 py-3">
          @switch($n['status'])
            @case('alert') <span class="badge-alert">🔴 Pelanggaran</span> @break
            @case('warn')  <span class="badge-warn">🟡 Perlu Pantau</span> @break
            @case('new')   <span class="badge-new">🔵 Data Baru</span>    @break
            @default       <span class="badge-aman">🟢 Aman</span>
          @endswitch
        </td>
        <td class="px-4 py-3 text-right">
          <a href="{{ route('dashboard.nik.detail', [
                'nik'  => $n['nik'],
                'nama' => $n['nama'],
                'from' => $from,
                'to'   => $to,
                'interval' => $minInterval,
             ]) }}"
             class="text-xs text-blue-600 hover:underline">Detail</a>
        </td>
      </tr>
      @empty
      <tr>
        <td colspan="10" class="px-4 py-10 text-center text-gray-400">
          Tidak ada data. Ubah filter atau jalankan scraping terlebih dahulu.
        </td>
      </tr>
      @endforelse
    </tbody>
  </table>
</div>

<p class="text-xs text-gray-400 mt-2">
  {{ $groups->count() }} individu ·
  {{ $from }} s/d {{ $to }}
  @if($pangkalanId) · Pangkalan: {{ $pangkalans->firstWhere('id', $pangkalanId)['label'] ?? $pangkalanId }} @endif
</p>

@endsection
